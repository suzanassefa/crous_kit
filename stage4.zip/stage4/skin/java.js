"use strict";

function OnSelectOption(){
  var e= document.getElementBYId("batiment");
  var strBat = e.value;
}
