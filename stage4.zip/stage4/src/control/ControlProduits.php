<?php

require_once("model/ProduitsStorage.php");
require_once("view/View.php");

class ControlProduits{
  protected $view;
  protected $produitsStorage;

  public function __construct(View $view, ProduitsStorage $produitsStorage, KitsStorage $kitsStorage){
    $this->view = $view;
    $this->produitsStorage = $produitsStorage;
    $this->kitsStorage = $kitsStorage;
  }

  public function showListProduit(){
    $this->view->HomePageList($this->produitsStorage->readAll(), $this->kitsStorage->readAll());
  }

  public function readContent($id){
    $this->view->HomePageContent($this->produitsStorage->read($id));
  }

  public function modifyAccueil(){
    $createKits = $this->kitsStorage->readAllCreateKit();
    $kits = $this->kitsStorage->readAll();
    $produits = $this->produitsStorage->readAll();
    $this->view->modifyAccueil($createKits, $kits,$produits);
  }

  public function addKit($data){
    var_dump($data);
    /**$buildEtudiant = new EtudiantsBuilder($data);
    if($buildEtudiant->isValid()){
      $etudiant = $buildEtudiant->newEtudiant($data, $id);
      $this->etudiantsStorage->addEtudiant($etudiant);
      $this->view->displaySuccess2Logement($id);
    }else{
      print("erreur");
      //$this->view->displayNewPretfailure();
    }**/
  }
  public function addProduit($data){

  }
  public function createKit($data){

  }

}
