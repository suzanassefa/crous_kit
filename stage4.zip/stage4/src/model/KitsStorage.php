<?php

class KitsStorage{
  protected $pdo;

  public function __construct($pdo){
    $this->pdo = $pdo;
  }

  public function readAll(){
    $requete = 'SELECT * FROM Kits;';
    $stmt = $this->pdo->query($requete);
    $tableau =$stmt->fetchAll();
    return $tableau;
  }

  public function read($id){
    $requete = "SELECT * FROM Kits WHERE idNom=:id";
		$stmt = $this->pdo->prepare($requete);
		$stmt->bindValue(":id" ,$id);
    //$data = array(":id" => $id);
		$stmt->execute();
		$tableau =$stmt->fetchAll();
		return $tableau;
  }

  public function readB($id){
    $requete = "SELECT * FROM StockTotal WHERE id=".$id.";";
    print("here");
    $stmt = $this->pdo->query($requete);
    $tableau =$stmt->fetch();
    return $tableau;
  }

  public function readAllCreateKit(){
    $requete = "SELECT * FROM CreateKit;";
    $stmt = $this->pdo->query($requete);
    $tableau =$stmt->fetchAll();
    return $tableau;
  }

}
