<?php


class Etudiants{
  protected $nom;
  protected $prenom;
  protected $num_tel;
  protected $logement;


  public function __construct($nom, $prenom, $num_tel, int $logement){
    $this->nom = $nom;
    $this->prenom = $prenom;
    $this->num_tel= $num_tel;
    $this->logement = $logement;
  }

  public function getNom(){
    return $this->nom;
  }
  public function getPrenom(){
    return $this->prenom;
  }
  public function getNumTel(){
    return $this->num_tel;
  }
  public function getLogement(){
    return $this->logement;
  }

}
