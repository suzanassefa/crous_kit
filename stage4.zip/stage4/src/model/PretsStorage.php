<?php


class PretsStorage{
  protected $pdo;

  public function __construct($pdo){
    $this->pdo = $pdo;
  }

  public function readPretParEtudiant($id){
    $requete = "SELECT * FROM Prets as P NATURAL JOIN Etudiants as Et WHERE P.etudiant = Et.idEtudiant and logement =".$id.";";
    $stmt = $this->pdo->query($requete);
    $pret = $stmt->fetchAll();
    return $pret;
  }
  public function addPret(Prets $pret){
    $s = $this->pdo->prepare('SELECT idKit FROM Kits WHERE nomKit = :nomKit and nbPers = :nbPers');
    $kit = $pret->getKit();
    $nbPers = $pret->getNbPers();
    $s->bindParam(':nomKit', $kit);
    $s->bindParam(':nbPers', $nbPers);
    $s->execute();
    $idKit = $s->fetch();

    $requete = 'INSERT INTO Prets (kit, etudiant, datePret, Payeur, estPayer, montantFacturer, dateDepartPrevu, observation) VALUES (?, ?, ?, ?, ?, ?, ?, ?);';
    $stmt = $this->pdo->prepare($requete);
    $data = array($idKit['idKit'], $pret->getEtudiant(), $pret->getDatePret(), $pret->getPayeur(), $pret->getEstPayer(), $pret->getMontantFacturer(), $pret->getDateDepartPrevu(), $pret->getObservation());
    $stmt->execute($data);

    //$requete = 'INSERT INTO RetourPret (pret,)'
  }

  public function read($id){
    $stmt = $this->pdo->prepare("SELECT * FROM Prets where idPret = :id");
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $ligne = $stmt->fetch();
    return $ligne;
  }

  public function update(Prets $pret, $id){
    $s = $this->pdo->prepare('SELECT idKit FROM Kits WHERE nomKit = :nomKit and nbPers = :nbPers');
    $kit = $pret->getKit();
    $nbPers = $pret->getNbPers();
    $s->bindParam(':nomKit', $kit);
    $s->bindParam(':nbPers', $nbPers);
    $s->execute();
    $idKit = $s->fetch();

    $requete = "UPDATE Prets SET kit=?, etudiant=?, datePret=?, Payeur=?, estPaye=?, montantFacturer=?, observation=? WHERE id = ?";
    $stmt = $this->pdo->prepare($requete);
    $data = array($idKit['idKit'], $pret->getEtudiant(), $pret->getDatePret(), $pret->getPayeur(), $pret->getEstPayer(), $pret->getMontantFacturer(),$pret->getObservation(), $id );
    $stmt->execute($data);
    return $stmt;
  }

  public function delete($id){
    $requete = "DELETE FROM Prets WHERE idPret=:id";
    $stmt = $this->pdo->prepare($requete);
    $stmt->bindParam(":id" ,$id, PDO::PARAM_INT);
    $stmt->execute();
    return true;
  }

  public function deleteParEtudiant($id){
    $requete = "DELETE FROM Prets WHERE etudiant=:id";
    $stmt = $this->pdo->prepare($requete);
    $stmt->bindParam(":id" ,$id, PDO::PARAM_INT);
    $stmt->execute();
    return true;
  }

}
