<?php
$this->content2 .= "<table>";


foreach($kits as $kit){
  $this->content2 .="<tr>
    <th>".$kit['nomKit']." ".$kit['nbPers']."prs</th>
    <td><ul>";
    foreach ($createKits as $ck) {
      if($kit['idKit']==$ck['kit']){
        foreach ($produits as $prd) {
          if($prd['idProduit']==$ck['produit']){
            $this->content2 .="<li>".$prd['nomProduit']." <a href='#'onclick='return confirm(\"Vous êtes sure de vouloir suprimer ".$prd['nomProduit']." ?\")'><img id='img-logo-delete' src='https://dev-21707895.users.info.unicaen.fr/stage/skin/deleteLogo.png' alt='deleteLogo'></a></li>";
          }
        }
      }
    }
    $this->content2 .="</ul><form method = 'POST' action='".$this->router->getCreateKitURL()."'>
      <input type ='text' id='produit' name='produit'>
      <input type='submit'  onclick='return confirm(\"Vous êtes sure de vouloir le ajouter ce Produit?\")' value='Ajouter un Produit'>
    </form></td>
  </tr>";
}


$this->content2 .="</table>";
