<?php
$this->content2 .=   "<form method = 'POST' action='".$this->router->getConfirmModificationPretURL($pretsLigne['idPret'], $logement['idLogements'])."'>

  <h3>".$logement['logement']." ".$etudiant['nom']." ".$etudiant['prenom']."</h3>
  <input type='hidden' id='idEtudiant' name='idEtudiant' value='".$pretsLigne['etudiant']."'>

  <label for='dateP'>Date de prêt</label>
  <input type='date' id='dateP' name='dateP' value= '".$pretsLigne['datePret']."' required>

</br></br>

  <label for='kit'>Kit</label>
  <select id='kit' name='kit' required>";
    if($pretsLigne['kit'] == 'kit-vaisselle'){
      $this->content2 .= "<option value='kit-vaisselle' selected>Kit Vaisselle</option>";}
    else{$this->content2 .=  "<option value='kit-vaisselle'>Kit Vaisselle</option>";}

    if($pretsLigne['kit'] == 'kit-serviette'){
      $this->content2 .= "<option value='kit-serviette' selected>Kit Serviette</option>";}
    else{$this->content2 .=  "<option value='kit-serviette'>Kit serviette</option>";}

    if($pretsLigne['kit'] == 'kit-literie'){
      $this->content2 .= "<option value='kit-literie' selected>Kit Literie</option>";}
    else{$this->content2 .=  "<option value='kit-literie'>Kit Literie</option>";}

    if($pretsLigne['kit'] == 'autre'){
      $this->content2 .= "<option value='autre' selected> Autre équipement</option>";}
    else{$this->content2 .=  "<option value='autre'>Autre équipement</option>";}


$this->content2 .=  "</select>
</br></br>
  <label for='nbPers'>1 ou 2 personnes</label>
  <select id='nbPers' name='nbPers' required>";

  //if($pretsLigne['kit'] == '1'){
    //$this->content2 .= "<option value='1' selected>1 </option>";}
  //else{$this->content2 .=  "<option value='1'>1 </option>";}

$this->content2 .="<option value='1'>1 </option>
    <option value='2'>2</option>
  </select>
  </br></br>

  <label for='payeur'>Payeur</label>
  <select id='payeur' name='payeur' required>
    <option value='etudiant'>etudiant </option>
    <option value='tiers-groupe'>tiers groupe</option>
  </select>
  </br></br>

  <label for='estPayer'>Montant à payer:</label>
  <input type = 'text' id='montant' name='montant' value= '".$pretsLigne['montantFacturer']."'>
  <input type='checkbox' id='estPayer' name='estPayer' >
  </br></br>

  <label for='dateP'>Date de départ prévu </label>
  <input type='date' id='dateDepartPrv' name='dateDepartPrv' value= '".$pretsLigne['dateDepartPrevu']."'>
   </br></br>

  <label for='dateP'>Date de retour</label>
  <input type='date' id='dateRetour' name='dateRetour' value= new DateTime('NOW')
       min='2020-01-01' max='2030-12-31' required>
   </br></br>

   <label for='etat'>Etat</label>
   <select id='etat' name='etat' required>
     <option value='blanchisseries'>blanchisserie</option>
     <option value='destruction'>destruction</option>
   </select>
   </br></br>

   <label for='observation'>Observation:</label>
   <input type ='text' id='observation' name='observation' value= '".$pretsLigne['observation']."'>

   </br></br>

  <input type='submit' value='Submit'>
</form>";


//"<label>Nom :<input type='text' name = 'nom' value = ".$paysLigne['nom']." required/></label>\n";
