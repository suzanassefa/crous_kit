<?php
require_once("Router.php");

class View{
  protected $router;
  protected $title;
  protected $content1;
  protected $content2;
  protected $menu;

  public function __construct(Router $router){
    $this->router = $router;
    $this->title = "";
    $this->content1 = "";
    $this->content2 = "";
    $this->menu = $this->getMenu();
  }

  public function render(){
    include_once("index.php");
  }

  public function getMenu(){
    return "<a href='".$this->router->getAccueilURL()."'>Accueil</a>
    <a href='".$this->router->getLogementsURL(3)."'>Logements</a>
    <a href='".$this->router->getBlanchisseriesURL()."'>Blanchisseries</a>
    <a href='".$this->router->getDeconnectionURL()."'>Deconnection</a>";
  }

  //***********************home page******************************//

  public function HomePageList($produits, $kits){
    $this->content1 = "<ul id='menu-accordeon'>
	     <li><a href='#'>Produits</a>
		   <ul>";
    foreach ($produits as $ligne){
      $this->content1 .= "<li><a href='".$this->router->getAccueilURL()."/produits/".$ligne['idProduit']."'>".$ligne['nomProduit']."</a></li>";
    }
    $this->content1 .= "</ul>
      </li>
      <li><a href=''#''>Kits</a>
		  <ul>";
    foreach ($kits as $ligne){
      //var_dump($ligne);
      $this->content1 .= "<li><a href='".$this->router->getAccueilURL()."/kits/".$ligne['idKit']."'>".$ligne['nomKit']." ".$ligne['nbPers']."</a></li>";
    }
    $this->content1 .= "</ul>
      </li>
      </ul>
      </br></br>

      <form method = 'POST' action='".$this->router->getAddProduitURL()."'>
        <input type ='text' id='produit' name='produit'>
        <input type='submit' onclick='return confirm(\"Vous êtes sure de vouloir le ajouter ce Produit ?\")' value='Ajouter un Produit'>

      </form>
      <form method = 'POST' action='".$this->router->getAddKitURL()."'>
        <input type ='text' id='kiit' name='kit'>
        <input type='submit'  onclick='return confirm(\"Vous êtes sure de vouloir le ajouter cette kit ?\")' value='Ajouter un Kit'>
      </form>

      </br></br>
      <a href = '".$this->router->getAccueilModificationURL()."' class='button'>Création de kit</a>

      ";
    //  $this->title = "Nom : ".$ligne['categorie']."</br>";
    //  $this->content2 .= "Inventaire : ".$ligne['inventaire']."</br>";
    //  $this->content2 .= "Date d'Inventaire : ".$ligne['dateInventaire']."</br>";
    //  $this->content2 .= "Quantié prêt : ".$ligne['pret']."</br>";
  }

  public function HomePageContent($ligne){
    $this->title = "Nom : ".$ligne['categorie'];
    $this->content2 .= "Inventaire : ".$ligne['inventaire'];
    $this->content2 .= "Date d'Inventaire : ".$ligne['dateInventaire'];
    $this->content2 .= "Quantié prêt : ".$ligne['pret'];

  }

  public function modifyAccueil($createKits, $kits, $produits){
    include_once('AccueilModification.php');
  }
//***************************Logement*********************//
  public function LogementList($batiments, $logement){
    $batimentActuel = 'A';
    include_once("LogementList.php");
  }

  public function LogementContent($kits, $etudiants, $prets, $idLog){
    include_once("LogementContent.php");
  }

  public function pretFormualire($logement, $etudiant){
    include_once("FormulairePret.php");
  }
  public function pretModificationForm($pretsLigne, $logement, $etudiant){
    include_once("ModificationPret.php");
  }

  public function etudiantFormulaire($id){
    $this->content2 .=   "<form method = 'POST' action='".$this->router->getSaveEtudiantURL($id)."'>
    <label for='nom'>Nom:</label>
    <input type ='text' id='nom' name='nom'>
    </br></br>
    <label for='prenom'>Prenom:</label>
    <input type ='text' id='prenom' name='prenom'>
    </br></br>
    <label for='num-tel'>Numeros de Téléphone:</label>
    <input type ='text' id='num-tel' name='num-tel'>
    </br></br>
   <input type='submit' value='Submit'>
   </form>";
  }

  ////////**************success failure********************////
  public function displaySuccess2Logement($id){
      $this->router->PostRedirect($this->router->getLogementsURL($id));
  }



  public function makeDebugPage($variable) {
		$this->title = "Debug";
		$this->content = "<pre>".htmlspecialchars(var_export($variable, true)).'</pre>';
	}
}
