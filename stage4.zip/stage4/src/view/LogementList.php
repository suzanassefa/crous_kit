<?php
$this->content1 .="<form onchange='this.form.submit()'>
  <select id='batiment' name='batiment' onchange='this.form.submit()'>";
  foreach ($batiments as $bat){
    $this->content1 .="<option value='".$bat['batiment']."'>".$bat['batiment']."</option>";
  }
  $this->content1 .="</select></br></br>
</form>";

if(isset($_GET["batiment"])){
  $batimentActuel = $_GET["batiment"];
}

$this->content1.= "</br></br> <ul>";
$this->content1.= "<h3> Batiement ".$batimentActuel."</h3>";
foreach ($logement as $log) {
  if($log['batiment']==$batimentActuel){
    $this->content1.="<li><a href='".$this->router->getLogementsURL($log['idLogements'])."'>".$log['logement']."</a></li>";
  }
}
$this->content1.= "</ul>";
