<!DOCTYPE HTML>
<html lang="fr">
  <head>
    <title> <?php echo $this->title; ?></title>
    <meta charset="utf-8"/>
    <link rel="stylesheet" href="<?php  echo $this->router->getStyleURL();?>" />
  </head>

  <body>

    <header id="header">
      <div class = "inner">
          <nav id="nav">
            <?php echo $this->menu;?>
          </nav>
      </div>
    </header>

    <section id= "section">
      <div class="inner">
        <div id="content1">
          <?php echo  $this->content1;?>
        </div>
        <div id="content2">
          <?php echo $this->title; ?>
          <?php echo  $this->content2;?>
        </div>
      </div>
    </section>
  </body>
</html>
