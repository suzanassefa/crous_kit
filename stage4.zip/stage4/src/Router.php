<?php

require_once("model/ProduitsStorage.php");
require_once("model/LogementsStorage.php");
require_once("model/EtudiantsStorage.php");
require_once("model/PretsStorage.php");
require_once("view/View.php");
require_once("control/ControlProduits.php");
require_once("control/ControlLogements.php");

class Router{
    protected $view;
    protected $control;
    protected $action;
    protected $id;

    public function _contruct(){
      $action = null;
      $id = 1;
    }

    public function main( ProduitsStorage $produitsStorage, LogementsStorage $logementsStorage, EtudiantsStorage $etudiantsStorage, PretsStorage $pretsStorage, KitsStorage $kitsStorage){
      $this->view = new View($this);
      $this->controlP = new ControlProduits($this->view, $produitsStorage, $kitsStorage);
      $this->controlL = new ControlLogements($this->view, $logementsStorage, $etudiantsStorage, $pretsStorage, $kitsStorage);

      //traitement de PATH_INFO
        if(key_exists("PATH_INFO", $_SERVER)){
        	$tab = explode('/', $_SERVER["PATH_INFO"]);
        	$taille=count($tab);
        	//print($tab[1]);
        	if($taille === 2){
        		$action = htmlspecialchars($tab[1]);
        	}if($taille >= 3){
        		$id = htmlspecialchars($tab[2]);
        		$action = htmlspecialchars($tab[1]);
            if($taille===4){
              $otherId = htmlspecialchars($tab[3]);
            }
            if($action == "produits" or $action == "kits"){
              $action = "accueil";
            }
        	}
        }else{$action = "accueil";}
        //$action = "accueil";

      try{
        switch ($action){
        case "accueil":
          $this->controlP->showListProduit();
          $this->controlP->readContent(2);
          break;
        case "modifyAccueil":
          $this->controlP->modifyAccueil();
          break;
        case "logements":
          $this->controlL->showLogement($id);
          break;
        case "pretFormulaire":
          $this->controlL->pretFormualire($id, $otherId);
          break;
        case "savePret":
          if($_SERVER["REQUEST_METHOD"] === "POST"){
            $this->controlL->saveNewPret($id, $_POST);
          }
          break;
        case "modify":
          $this->controlL->modifyPrets($id, $otherId);
          break;
        case "confirmModification":
          if($_SERVER["REQUEST_METHOD"] === "POST"){
					    $this->controlL->confirmModification($otherId, $_POST, $id);
				  }
          break;
        case "deletePret":
          $this->controlL->deletePret($id, $otherId);
          break;
        case 'etudiantFormulaire':
          $this->view->etudiantFormulaire($id);
          break;
        case 'saveEtudiant':
          if($_SERVER["REQUEST_METHOD"] === "POST"){
            $this->controlL->saveNewEtudiant($id, $_POST);
          }
          break;
        case 'deleteEtudiant':
          $this->controlL->deleteEtudiant($id, $otherId);
          break;
        case 'addKit':
          if($_SERVER["REQUEST_METHOD"] === "POST"){
            $this->controlP->addKit($_POST);
          }
          break;
        case 'addProduit':
          if($_SERVER["REQUEST_METHOD"] === "POST"){
            $this->controlP->addProduit($_POST);
          }
          break;
        case 'createKit':
          if($_SERVER["REQUEST_METHOD"] === "POST"){
            $this->controlP->createKit($_POST);
          }
          break;
        default:
          $variable = "erreur au niveau du default";
          //makeDebugPage
          break;
        }
      }catch(Exception $e){
        $variable = "erreur au niveau du catch";
        //makeDebugPage
      }
      $this->view->render();
    }

  public function getAccueilURL(){
    return "https://dev-21707895.users.info.unicaen.fr/stage/index.php";
    //return "http://srv-phpmysql.in.crous-normandie.fr:8080/index.php";
  }
  public function getStyleURL(){
    return "https://dev-21707895.users.info.unicaen.fr/stage/skin/main.css";
    //return "http://srv-phpmysql.in.crous-normandie.fr:8080/skin/main.css";
  }

  /////////////////////Accueil//////////////////////////

  public function getAccueilModificationURL(){
    return $this->getAccueilURL()."/modifyAccueil";
  }
  public function getAddKitURL(){
    return $this->getAccueilURL()."/addKit";
  }
  public function getAddProduitURL(){
    return $this->getAccueilURL()."/addProduit";
  }
  public function getCreateKitURL(){
    return $this->getAccueilURL()."/createKit";
  }
   ////////////////////Logement////////////////////////
  public function getLogementsURL($id){
    return $this->getAccueilURL()."/logements/".$id;
  }
  public function getPretFormulaireURL($idEtudiant, $idLog){
    return $this->getAccueilURL()."/pretFormulaire/".$idEtudiant."/".$idLog;
  }
  public function getSavePretURL($id){
    return $this->getAccueilURL()."/savePret/".$id;
  }
  public function getModifyPretURL($idPret, $idLog){
    return $this->getAccueilURL()."/modify/".$idPret."/".$idLog;
  }
  public function getConfirmModificationPretURL($id, $idLog){
    return $this->getAccueilURL()."/confirmModification/".$id."/".$idLog;
  }
  public function getDeletePretURL($idPret, $idLog){
    return $this->getAccueilURL()."/deletePret/".$idPret."/".$idLog;
  }

  public function getEtudiantFormulaireURL($idLog){
    return $this->getAccueilURL()."/etudiantFormulaire/".$idLog;
  }

  public function getSaveEtudiantURL($id){
    return $this->getAccueilURL()."/saveEtudiant/".$id;
  }

  public function getDeleteEtudiantURL($idEtu, $idLog){
    return $this->getAccueilURL()."/deleteEtudiant/".$idEtu."/".$idLog;

  }
  /////////////////////////Blanchisseries///////////
  public function getBlanchisseriesURL(){
    return $this->getAccueilURL()."/blanchisseries";
  }
  public function getDeconnectionURL(){
    return $this->getAccueilURL()."/deconnection";
  }

  public function PostREDIRECT($url){
    header("Location: ".htmlspecialchars_decode($url), true, 303);
  }
}
