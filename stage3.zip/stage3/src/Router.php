<?php
require_once("model/ProduitsStorage.php");
require_once("view/View.php");
require_once("control/ControlProduits.php");
require_once("control/ControlLogements.php");

class Router{
    protected $view;
    protected $control;
    protected $action;
    protected $id;

    public function _contruct(){
      $action = null;
      $id = 1;
    }

    public function main( ProduitsStorage $produitsStorage, LogementsStorage $logementsStorage){
      $this->view = new View($this);
      $this->controlP = new ControlProduits($this->view, $produitsStorage);
      $this->controlL = new ControlLogements($this->view, $logementsStorage);

      //traitement de PATH_INFO
        if(key_exists("PATH_INFO", $_SERVER)){
        	$tab = explode('/', $_SERVER["PATH_INFO"]);
        	$taille=count($tab);
        	//print($tab[1]);
        	if($taille === 2){
        		$action = htmlspecialchars($tab[1]);
        	}if($taille === 3){
        		$id = htmlspecialchars($tab[2]);
        		$action = htmlspecialchars($tab[1]);
            if($action == "produits" or $action == "kits"){
              $action = "accueil";
            }
        	}
        }else{$action = "accueil";}
        //$action = "accueil";

      try{
        switch ($action){
        case "accueil":
          $this->controlP->showListProduit();
          $this->controlP->readContent(2);
          break;
        case "logements":
          $this->controlL->showLogement();
          break;
        case "kitFormulaire":
          $this->view->kitFormualire();
          break;
        default:
          $variable = "erreur au niveau du default";
          //makeDebugPage
          break;
        }
      }catch(Exception $e){
        $variable = "erreur au niveau du catch";
        //makeDebugPage
      }
      $this->view->render();
    }

  public function getAccueilURL(){
    //return "https://dev-21707895.users.info.unicaen.fr/stage/index.php";
    return "http://srv-phpmysql.in.crous-normandie.fr:8080/index.php";
  }
  public function getStyleURL(){
    //return "https://dev-21707895.users.info.unicaen.fr/stage/skin/main.css";
    return "http://srv-phpmysql.in.crous-normandie.fr:8080/skin/main.css";
  }
  public function getLogementsURL(){
    return $this->getAccueilURL()."/logements";
  }
  public function getKitFormulaireURL(){
    return $this->getAccueilURL()."/kitFormulaire";
  }
  public function getBlanchisseriesURL(){
    return $this->getAccueilURL()."/blanchisseries";
  }
  public function getDeconnectionURL(){
    return $this->getAccueilURL()."/deconnection";
  }
}
