<?php
$this->content2 .=   "<form action=''/action_page.php'>
  <label for='fname'>First Name</label>
  <input type='text' id='fname' name='firstname' placeholder='Your name..'>

  <label for='dateP'>Date de prêt</label>
  <input type='date' id='dateP' name='dateP' value= new DateTime('NOW')
       min='2020-01-01' max='2030-12-31'>

  <label for='kit'>Kit</label>
  <select id='kit' name='kit'>
    <option value='kit-vaisselle'>Kit Vaisselle</option>
    <option value='kit-serviette'>Kit serviette</option>
    <option value='kit-litterie'>Kit Literie</option>
    <option value='autre'>Autre équipement</option>
  </select>

  <label for='nbPers'>1 ou 2 personnes</label>
  <select id='nbPers' name='nbPers'>
    <option value='1pers'>1 </option>
    <option value='2pers'>2</option>
  </select>
  <label for='dateP'>Date de retour</label>
  <input type='date' id='dateP' name='dateP' value= new DateTime('NOW')
       min='2020-01-01' max='2030-12-31'>
  <input type='submit' value='Submit'>
</form>";
