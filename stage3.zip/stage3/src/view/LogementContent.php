<?php
$this->content1 .="<form methode='POST' action='".$this->router->getAccueilURL()."/'>
  <label for='batiement'>Batiement</label>
  <select id='batiment' name='batiment'>";
  foreach ($batiments as $bat){
    $this->content1 .="<option value='".$bat['batiment']."'>".$bat['batiment']."</option>";
  }
  $this->content1 .="</select></br></br>
  <label for='etage'>Etage</label>
  <select id='etage' name='etage'>";
  foreach ($etages as $et){
    $this->content1 .="<option value='".$et['etages']."'>".$et['etages']."</option>";
  }
  $this->content1 .="</select>
</form>";

$this->content2 .=
  "  <table>
      <tr>
        <th>Nom Etudiant</th>
        <th>Date de départ prévu : </th>
      <tr>
      <tr>
        <th>Nom du kit</th>
        <th>Date de pet</th>
        <th>Mantant facturé</th>
        <th>Payeur</th>
        <th>Observation</th>
        <th>Date de Retour</th>
        <th>Etat</th>
      </tr>
      <tr>
        <td>Alfreds Futterkiste</td>
        <td>Maria Anders</td>
        <td>Germany</td>
      </tr>
    </table>
    ";
