<?php

class Produits{
  protected $nom;
  //protected $lieuStokage;
  protected $quantite;
  protected $description;
  protected $type;

  public function __construct($nom, $quantite, $description, $type){
    $this->nom = $nom;
    $this->quantite = $quantite;
    $this->description = $description;
    $this->type = $type;
  }

  public function getNom(){
    return $this->nom;
  }

  public function getQuantite(){
    return $this->quantite;
  }

  public function getDescription(){
    return $this->description;
  }

  public function getType(){
    return $this->type;
  }
}
