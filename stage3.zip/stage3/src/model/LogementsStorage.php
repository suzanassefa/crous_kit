<?php

class LogementsStorage{
  protected $pdo;

  public function __construct($pdo){
    $this->pdo = $pdo;
  }

  public function readAll(){
    $requete = 'SELECT * FROM Logements;';
    $stmt = $this->pdo->query($requete);
    $tableau =$stmt->fetchAll();
    return $tableau;
  }

  public function readBatiments(){
    $requete = 'SELECT DISTINCT batiment FROM Logements;';
    $stmt = $this->pdo->query($requete);
    $batiments = $stmt->fetchAll();
    return $batiments;
  }

  public function readEtages(){
    $requete = 'SELECT DISTINCT etages FROM Logements;';
    $stmt = $this->pdo->query($requete);
    $etages = $stmt->fetchAll();
    return $etages;
  }

  public function readLogement($id){
    $requete = "SELECT * FROM Logements WHERE idLogement=:id";
    //$requete = "SELECT * FROM Logements WHERE id=".$id.";";
    //$stmt = $this->pdo->query($requete);
		$stmt = $this->pdo->prepare($requete);
		$stmt->bindValue(":id" ,$id);
    //$data = array(":id" => $id);
		$stmt->execute();
		$tableau =$stmt->fetchAll();
		return $tableau;
  }

  public function readEtudiant($id){
    $requete = "SELECT * FROM Etudiants WHERE logement=".$id.";";
    $stmt = $this->pdo->query($requete);
    $etudiant = $stmt->fetchAll();
    return $etudiant;
  }

  public function readPret($id){
    $requete = "SELECT * FROM Prets WHERE etudiant=".$this->readEtudiant($id)['idEtudiant'].";";
    $stmt = $this->pdo->query($requete);
    $pret = $stmt->fetchAll();
    return $pret;
  }

}
