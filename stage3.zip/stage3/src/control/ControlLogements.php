<?php

require_once("model/Logements.php");
require_once("view/View.php");

class ControlLogements{
  protected $view;
  protected $logementsStorage;

  public function __construct(View $view, LogementsStorage $logementsStorage){
    $this->view = $view;
    $this->logementsStorage = $logementsStorage;
  }

  public function showLogement(){
    $this->view->LogementList($this->logementsStorage->readBatiments(),$this->logementsStorage->readEtages());
  //  $this->view->LogementContent($this->logementsStorage->readBatiments(),$this->logementsStorage->readEtages());
  var_dump($this->logementsStorage->readEtudiant(3));
    var_dump($this->logementsStorage->readPret(3));
  }

}
