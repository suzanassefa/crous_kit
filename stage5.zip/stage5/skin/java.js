"use strict";

function OnSelectOption(){
  var e= document.getElementBYId("batiment");
  var strBat = e.value;
}


function afficherListe(togg2, d2){
  let toggle = document.getElementById(togg2);
  let d = documen.getElementById(d2);

  if(getComputedStyle(d).display != "none"){
    d.style.display = "none";
  } else {
    d.style.display = "block";
  }
};

//togg2.onclick = togg;
//}
