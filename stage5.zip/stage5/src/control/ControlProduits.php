<?php

require_once("model/ProduitsStorage.php");
require_once("model/KitsBuilder.php");
require_once("view/View.php");

class ControlProduits{
  protected $view;
  protected $produitsStorage;

  public function __construct(View $view, ProduitsStorage $produitsStorage, KitsStorage $kitsStorage){
    $this->view = $view;
    $this->produitsStorage = $produitsStorage;
    $this->kitsStorage = $kitsStorage;
  }

  public function showListProduit(){
    $this->view->HomePageList($this->produitsStorage->readAll(), $this->kitsStorage->readAll());
  }


  public function kits($id){
    $kit = $this->kitsStorage->read($id);
    $createKits = $this->kitsStorage->readAllCreateKit($kit['idKit']);
    $produits = $this->produitsStorage->readAll();
    $this->view->HomePageContentKit($createKits, $kit,$produits);
  }

  public function produits($id){
    $produit = $this->produitsStorage->read($id);
    $this->view->HomePageContentProduit($produit);
  }

  public function modifyAccueilKit($id){
    //$createKits = $this->kitsStorage->readAllCreateKit();
    //$kits = $this->kitsStorage->readAll();
    //$produits = $this->produitsStorage->readAll();
    $kit = $this->kitsStorage->read($id);
    $createKits = $this->kitsStorage->readAllCreateKit($kit['idKit']);
    $produits = $this->produitsStorage->readAll();
    $this->view->modifyAccueilKit($createKits, $kit,$produits);
  }

  public function modifyAccueilProduit($id){
    $produit = $this->produitsStorage->read($id);
    $this->view->modifyAccueilProduit($produit);
  }
  public function createKit($data){
    //var_dump($data);
    if($data['produit'] !== ""){
      $this->kitsStorage->createKit($data);
      $this->view->displaySuccess2AccueilModification();
    }else{
      print("erreur");
      //$this->view->displayNewPretfailure();
    }
  }
  public function deleteProduitCK($idP, $idK){
    if($this->kitsStorage->delete($idP, $idK)){
      $this->view->displaySuccess2AccueilModification();
    }
    else{
      $variable = "erreur";
      $this->view->makeDebugPage();
      //$this->view->makeUnexpectedErrorPage() ;
    }
  }


    public function addKit($data){
      $buildKit = new KitsBuilder($data);
      if($buildKit->isvalid($data)){
        $kit = $buildKit->newKit($data);
        $this->kitsStorage->addKit($kit);
        $this->view->displaySuccess2AccueilModification();
      }else{
        $variable = "erreur";
        $this->view->makeDebugPage($variable);
        //$this->view->displayNewPretfailure();
      }
    }

    public function addProduit($data){
      var_dump($data);
    }

    public function deleteKit($id){
      if($this->kitsStorage->deleteKit($id)){
        $this->view->displaySuccess2AccueilModification();
      }
      else{
        $variable = "erreur ";
        $this->view->makeDebugPage();
        //$this->view->makeUnexpectedErrorPage() ;
      }
    }

    public function modifyKit($data, $id){
      $buildKit = new KitsBuilder($data);
      if($buildKit->isValid($data)){
        $kit = $buildKit->newKit($data);
        $this->kitsStorage->updateKit($kit, $id);
        $this->view->displaySuccess2AccueilModification();
      }else{
        $variable = "erreur";
        $this->view->makeDebugPage($variable);
        //$this->view->displayNewPretfailure();
      }
    }


}
