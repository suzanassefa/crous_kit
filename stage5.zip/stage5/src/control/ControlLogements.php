<?php

require_once("model/Logements.php");
require_once("model/EtudiantsBuilder.php");
require_once("model/PretsBuilder.php");
require_once("view/View.php");

class ControlLogements{
  protected $view;
  protected $logementsStorage;
  protected $etudiantsStorage;
  protected $pretsStorage;
  protected $kitsStorage;

  public function __construct(View $view, LogementsStorage $logementsStorage, EtudiantsStorage $etudiantsStorage, PretsStorage $pretsStorage, KitsStorage $kitsStorage){
    $this->view = $view;
    $this->logementsStorage = $logementsStorage;
    $this->etudiantsStorage = $etudiantsStorage;
    $this->pretsStorage = $pretsStorage;
    $this->kitsStorage = $kitsStorage;
  }

  public function showLogement($id){
    $this->view->LogementList($this->logementsStorage->readBatiments(), $this->logementsStorage->readAll());

    $etudiants= $this->etudiantsStorage->readEtudiantParLogement($id);
    $prets= $this->pretsStorage->readPretParEtudiant($id);
    $kits = $this->kitsStorage->readAll();
    $this->view->LogementContent($kits, $etudiants,$prets, $id);
  }

  public function pretFormualire($idEtu, $idLog){
    $etudiant = $this->etudiantsStorage->readEtudiant($idEtu);
    $logement = $this->logementsStorage->read($idLog);
    if($etudiant !== NUll and $logement !== NULL){
      $this->view->pretFormualire($logement, $etudiant);
    }
  }

  public function saveNewPret($idLog, array $data){
    $buildPret = new PretsBuilder($data);
    if($buildPret->isValid()){
      $pret = $buildPret->newPret($data);
      $this->pretsStorage->addPret($pret);
      $this->view->displaySuccess2Logement($idLog);
    }else{
      print("erreur");
      //$this->view->displayNewPretfailure();
    }
  }

  public function modifyPrets($id, $idLog){
    $pretLigne = $this->pretsStorage->read($id);
    $etudiant = $this->etudiantsStorage->readEtudiant($pretLigne['etudiant']);
    $logement = $this->logementsStorage->read($idLog);
    if($pretLigne !== Null and $etudiant !== NUll and $logement !== NULL){
      $this->view->pretModificationForm($pretLigne, $logement, $etudiant);
		}
		//else{$this->view->makeUnexpectedErrorPage();}
  }

  public function confirmModification($idLog, array $data, $id){
    $buildPret = new PretsBuilder($data);
    if($buildPret->isValid()){
      $pret = $buildPret->pretWithRetour($data);
      $this->pretsStorage->update($pret, $id);
      $this->view->displaySuccess2Logement($idLog);
    }
  }
  //else{$this->view->displayUpdateFailure();}

  public function deletePret($id, $idLog){
    if($this->pretsStorage->delete($id)){
      $this->view->displaySuccess2Logement($idLog);
    }else{
      $this->view->makeDebugPage("erreur de supression");
    }
  }

  public function saveNewEtudiant($id, $data){
    $buildEtudiant = new EtudiantsBuilder($data);
    if($buildEtudiant->isValid()){
      $etudiant = $buildEtudiant->newEtudiant($data, $id);
      $this->etudiantsStorage->addEtudiant($etudiant);
      $this->view->displaySuccess2Logement($id);
    }else{
      print("erreur");
      //$this->view->displayNewPretfailure();
    }
  }

  public function deleteEtudiant($id, $idLog){
    $p = $this->pretsStorage->deleteParEtudiant($id);
    $e = $this->etudiantsStorage->delete($id);
    if( $e and $p){
      $this->view->displaySuccess2Logement($idLog);
    }else{
      $this->view->makeDebugPage("erreur de supression");
    }
  }
}
