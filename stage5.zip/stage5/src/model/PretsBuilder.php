<?php
require_once('model/Prets.php');


class PretsBuilder{
  public $data;
  public $errors;

  public function __contruct($data, $errors=null){
    $this->data = $data;
  }

  public function getData(){
    return $this->data;
  }

  public function getErrors(){
    return $this->errors;
  }

  //public function saveKit($n)

  public function isValid(){
    if($_POST['idEtudiant'] != ""
    and $_POST['dateP'] != ""
    and $_POST['kit'] != ""
    and $_POST['nbPers'] != ""){
      return true;
    }else{
      $this->errors = "Les champs ne sont pas rempli avec des données coorecte.";
      return false;
    }

  }

  public function newPret($data){
    if($_POST['estPayer'] != ""){
      $_POST['estPayer'] =  0;
    }else{$_POST['estPayer'] = 1;}
    return new Prets(htmlspecialchars($_POST['kit']), htmlspecialchars($_POST['idEtudiant']), htmlspecialchars($_POST['dateP']),htmlspecialchars($_POST['nbPers']), htmlspecialchars($_POST['estPayer']),htmlspecialchars($_POST['payeur']), htmlspecialchars($_POST['montant']),
    htmlspecialchars($_POST['dateDepartPrv']), htmlspecialchars($_POST['observation']) );
  }

  public function pretWithRetour($data){
    if($_POST['estPayer'] != ""){
      $_POST['estPayer'] =  0;
    }else{$_POST['estPayer'] = 1;}
    return new Prets(htmlspecialchars($_POST['kit']), htmlspecialchars($_POST['idEtudiant']), htmlspecialchars($_POST['dateP']),htmlspecialchars($_POST['nbPers']), htmlspecialchars($_POST['estPayer']),htmlspecialchars($_POST['payeur']), htmlspecialchars($_POST['montant']),
    htmlspecialchars($_POST['dateDepartPrv']), htmlspecialchars($_POST['observation']), htmlspecialchars($_POST['dateRetour']), htmlspecialchars($_POST['etat']) );
  }
}
