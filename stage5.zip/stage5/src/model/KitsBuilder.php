<?php
require_once('model/Kits.php');


class KitsBuilder{
  public $data;
  public $errors;

  public function __contruct($data, $errors=null){
    $this->data = $data;
  }

  public function getData(){
    return $this->data;
  }

  public function getErrors(){
    return $this->errors;
  }

  //public function saveKit($n)

  public function isValid($data){

    if($_POST['nomKit'] != ""
    and $_POST['nbPers'] != ""){
      return true;
    }else{
      $this->errors = "Les champs ne sont pas rempli avec des données coorecte.";
      return false;
    }

    /**if($_POST['nomKit'] === "" and $_POST['nbPers'] === "" ){
      $this->errors = "Les kit et le nombre de personne ne sont pas donnée.";
      return false;
    }
     if(!is_float($_POST['tarif-annuel']) or !is_int($_POST['tarif-annuel']) or !is_float($_POST['tarif-semaine']) or !is_int($_POST['tarif-semaine'])){
      $this->errors = "Les champs ne sont pas rempli avec des données coorecte, donnez que la valeur du prix.";
      return false;
    }
    return true;**/
  }

  public function newKit($data){
    return new Kits(htmlspecialchars($data['nomKit']), intval($data['nbPers']), floatval($data['tarif-semaine']), floatval($data['tarif-annuel']),htmlspecialchars($data['description']));
  }

}
