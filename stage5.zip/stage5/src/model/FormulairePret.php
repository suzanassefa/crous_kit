<?php
$this->content2 .=   "<form method = 'POST' action='".$this->router->getSavePretURL($logement['idLogements'])."'>
<input type='hidden' id='idEtudiant' name='idEtudiant' value='".$etudiant['idEtudiant']."'>

<h3>".$logement['logement']." ".$etudiant['nom']." ".$etudiant['prenom']."</h3>
  <label for='dateP'>Date de prêt</label>
  <input type='date' id='dateP' name='dateP' value= new DateTime('NOW')
       min='2020-01-01' max='2030-12-31' required>

</br></br>

  <label for='kit'>Kit</label>
  <select id='kit' name='kit' required>
    <option value='kit-vaisselle'>Kit Vaisselle</option>
    <option value='kit-serviette'>Kit serviette</option>
    <option value='kit-literie'>Kit Literie</option>
    <option value='autre'>Autre équipement</option>
  </select>

</br></br>

  <label for='nbPers'>1 ou 2 personnes</label>
  <select id='nbPers' name='nbPers' required>
    <option value='1'>1 </option>
    <option value='2'>2</option>
  </select>

  </br></br>
  <label for='payeur'>Payeur</label>
  <select id='payeur' name='payeur' required>
    <option value='etudiant'>etudiant </option>
    <option value='tiers-groupe'>tiers groupe</option>
  </select>

  </br></br>

  <label for='estPayer'>Montant à payer:</label>
  <input type = 'text' id='montant' name='montant' value= '3'>
  <input type='checkbox' id='estPayer' name='estPayer' >

  </br></br>
  <label for='dateP'>Date de départ prévu </label>
  <input type='date' id='dateDepartPrv' name='dateDepartPrv' value= new DateTime('NOW')
       min='2020-01-01' max='2030-12-31' required>

   </br></br>

   <label for='observation'>Observation:</label>
   <input type ='text' id='observation' name='observation'>

   </br></br>

  <input type='submit' value='Submit'>
</form>";


//"<label>Nom :<input type='text' name = 'nom' value = ".$paysLigne['nom']." required/></label>\n";
