<?php

class LogementsStorage{
  protected $pdo;

  public function __construct($pdo){
    $this->pdo = $pdo;
  }

  public function readAll(){
    $requete = 'SELECT * FROM Logements;';
    $stmt = $this->pdo->query($requete);
    $tableau =$stmt->fetchAll();
    return $tableau;
  }

  public function readBatiments(){
    $requete = 'SELECT DISTINCT batiment FROM Logements;';
    $stmt = $this->pdo->query($requete);
    $batiments = $stmt->fetchAll();
    return $batiments;
  }

  public function readAppartements($batiment, $etages){
    $requete = "SELECT * FROM Logements WHERE batiment=:batiment and etages=:etages;";
    $stmt = $this->pdo->prepare($requete, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
    $data = array(":batiment"=> $batiment, ":etages"=>$etages);
    $stmt->execute($data);
    $tableau =$stmt->fetchAll();
    return $tableau;
  }


  public function read($id){
    $requete = "SELECT * FROM Logements WHERE idLogements=:id;";
		$stmt = $this->pdo->prepare($requete);
    $data = array(':id' => $id);
    $stmt->execute($data);
    $ligne =$stmt->fetch();
    return $ligne;
  }



}
