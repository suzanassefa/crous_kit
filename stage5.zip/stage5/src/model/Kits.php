<?php

class Kits{
  protected $nom;
  protected $nbPersonne;
  protected $description;
  protected $tarifSemaine;
  protected $tarifAnnuel;

  public function __construct($nom, $nbPersonne, $tarifSemaine, $tarifAnnuel, $description=NULL){
    $this->nom = $nom;
    $this->nbPersonne = $nbPersonne;
    $this->description = $description;
    $this->tarifSemaine = $tarifSemaine;
    $this->tarifAnnuel = $tarifAnnuel;
  }

  public function getNom(){
    return $this->nom;
  }

  public function getNbPersonne(){
    return $this->nbPersonne;
  }

  public function getDescription(){
    return $this->description;
  }

  public function getTarifAnnuel(){
    return $this->tarifAnnuel;
  }
  public function getTarifSemaine(){
    return $this->tarifSemaine;
  }
}
