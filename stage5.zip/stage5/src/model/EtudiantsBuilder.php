<?php
require_once('model/Etudiants.php');


class EtudiantsBuilder{
  public $data;
  public $errors;

  public function __contruct($data, $errors=null){
    $this->data = $data;
  }

  public function getData(){
    return $this->data;
  }

  public function getErrors(){
    return $this->errors;
  }

  //public function saveKit($n)

  public function isValid(){
    if($_POST['nom'] != ""
    and $_POST['prenom'] != ""
    and $_POST['num-tel'] != ""){
      return true;
    }else{
      $this->errors = "Les champs ne sont pas rempli avec des données coorecte.";
      return false;
    }

  }

  public function newEtudiant($data, $id){
    return new Etudiants(htmlspecialchars($_POST['nom']), htmlspecialchars($_POST['prenom']), htmlspecialchars($_POST['num-tel']), $id);
  }

}
