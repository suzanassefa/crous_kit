<?php


class EtudiantsStorage{
  protected $pdo;

  public function __construct($pdo){
    $this->pdo = $pdo;
  }

  public function readAll(){
    $requete = 'SELECT * FROM Etudiants;';
    $stmt = $this->pdo->query($requete);
    $tableau =$stmt->fetchAll();
    return $tableau;
  }

  public function readEtudiantParLogement($id){
    $requete = "SELECT * FROM Etudiants WHERE logement=".$id.";";
    $stmt = $this->pdo->query($requete);
    $etudiants = $stmt->fetchAll();
    return $etudiants;
  }

  public function readEtudiant($id){
    $requete = "SELECT * FROM Etudiants WHERE idEtudiant=:idEtudiant;";
    $stmt = $this->pdo->prepare($requete);
    $data = array(':idEtudiant' => $id);
    $stmt->execute($data);
    $ligne =$stmt->fetch();
    return $ligne;
  }

  public function addEtudiant($etudiant){
    $requete = "INSERT INTO Etudiants (nom, prenom, numerosTel, logement) VALUES (?,?,?,?);";
    $stmt = $this->pdo->prepare($requete);
    $data = array($etudiant->getNom(), $etudiant->getPrenom(), $etudiant->getNumTel(), $etudiant->getLogement());
    $stmt->execute($data);
  }

  public function delete($id){
    $requete = "DELETE FROM Etudiants WHERE idEtudiant=:id";
    $stmt = $this->pdo->prepare($requete);
    $stmt->bindParam(":id" ,$id, PDO::PARAM_INT);
    $stmt->execute();
    return true;
  }

}
