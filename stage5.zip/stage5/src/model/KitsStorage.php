<?php

class KitsStorage{
  protected $pdo;

  public function __construct($pdo){
    $this->pdo = $pdo;
  }

  public function readAll(){
    $requete = 'SELECT * FROM Kits;';
    $stmt = $this->pdo->query($requete);
    $tableau =$stmt->fetchAll();
    return $tableau;
  }

  public function read($id){
    $requete = "SELECT * FROM Kits WHERE idKit=:id";
		$stmt = $this->pdo->prepare($requete);
		$stmt->bindValue(":id" ,$id);
		$stmt->execute();
		$tableau =$stmt->fetch();
		return $tableau;
  }

  public function addKit($kit){
    $requete = "INSERT INTO Kits (nomKit, nbPers, descriptionK) VALUES (?,?,?);";
    $stmt = $this->pdo->prepare($requete);
    $d = array($kit->getNom(), $kit->getNbPersonne(), $kit->getDescription());
    $stmt->execute($d);
  }

  public function readB($id){
    $requete = "SELECT * FROM StockTotal WHERE id=".$id.";";
    $stmt = $this->pdo->query($requete);
    $tableau =$stmt->fetch();
    return $tableau;
  }

  public function readAllCreateKit(){
    $requete = "SELECT * FROM CreateKit;";
    $stmt = $this->pdo->query($requete);
    $tableau =$stmt->fetchAll();
    return $tableau;
  }

  public function readCreateKit($id){
    $requete = "SELECT * FROM CreateKit WHERE kit=:id;";
    $stmt = $this->pdo->prepare($requete);
		$stmt->bindValue(":id" ,$id);
		$stmt->execute();
		$tableau =$stmt->fetchAll();
		return $tableau;
  }

  public function createKit($data){
    $requete = 'INSERT INTO CreateKit (kit, produit, quantite) VALUES (?, ?, ?);';
    $stmt = $this->pdo->prepare($requete);
    $data = array($data['kit'], $data['produit'], $data['quantite']);
    $stmt->execute($data);
  }

  public function delete($idP, $idK){
    $requete = 'DELETE FROM CreateKit WHERE produit=:idP  and kit=:idK';
    $stmt = $this->pdo->prepare($requete);
    $stmt->bindParam(":idP" ,$idP, PDO::PARAM_INT);
    $stmt->bindParam(":idK" ,$idK, PDO::PARAM_INT);
    //$stmt->bindValue(":id" ,$id);
    $stmt->execute();
    return true;
  }

  public function deleteKit($id){
    $requete = 'DELETE FROM Kits WHERE idKit=:id';
    $stmt = $this->pdo->prepare($requete);
    $stmt->bindParam(":id" ,$id, PDO::PARAM_INT);
    $stmt->execute();
    return true;
  }

  public function updateKit(Kits $kit, $id){
      $requete = "UPDATE Kits SET nomKit=?, nbPers=?, descriptionK=? WHERE idKit= ?";
      $stmt = $this->pdo->prepare($requete);
      $data = array($kit->getNom(), $kit->getNbPersonne(), $kit->getDescription(),$id);
      $stmt->execute($data);
      return $stmt;
    }

}
