<?php

class ProduitsStorage{
  protected $pdo;

  public function __construct($pdo){
    $this->pdo = $pdo;
  }

  public function readAll(){
    $requete = 'SELECT * FROM Produits;';
    $stmt = $this->pdo->query($requete);
    $tableau =$stmt->fetchAll();
    return $tableau;
  }

  public function read($id){
    $requete = "SELECT * FROM Produits WHERE idProduit=:id";
		$stmt = $this->pdo->prepare($requete);
		$stmt->bindValue(":id" ,$id);
		$stmt->execute();
		$tableau =$stmt->fetch();
		return $tableau;
  }

  public function readStockB($id){
    $requete = "SELECT * FROM StockTotal WHERE id=".$id.";";
    $stmt = $this->pdo->query($requete);
    $tableau =$stmt->fetch();
    return $tableau;
  }


}
