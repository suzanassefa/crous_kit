<?php

class Logements{
  protected $logement;
  protected $batiment;
  protected $numeros;
  protected $type;

  public function __construct($logement, $batiment, $type){
    $this->logement = $logement;
    $this->batiment = $batiment;
    $this->type = $type;
  }

  public function getLogement(){
    return $this->logement;
  }

  public function getBatiment(){
    return $this->batiment;
  }

  public function getType(){
    return $this->type;
  }
}
