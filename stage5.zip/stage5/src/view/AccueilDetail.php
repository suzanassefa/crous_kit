<?php

//foreach($kits as $kit){
  $this->content2 .="
  <tr>
    <th>Inventaire</th>
    <td></td>
  </tr>
  <tr>
    <th>Date d'inventaire</th>
    <td></td>
  </tr>
  <tr>
    <th>Stock Total</th>
    <td></td>
  </tr>
  <tr>
    <th>Stock LCR</th>
    <td></td>
  </tr>
  <tr>
    <th>Stock LOGE</th>
    <td></td>
  </tr>
  <tr>
    <th>Stock Cave</th>
    <td></td>
  </tr>
  <tr>
    <th>Stock Autres</th>
    <td></td>
  </tr>
  <tr>
    <th>Quantité de Prêt</th>
    <td></td>
  </tr>";
//}
