<?php
$this->content1 .="<div class='content1Logement'><form >
  <select id='batiment' name='batiment' onchange='this.form.submit()'>";
  foreach ($batiments as $bat){
    $this->content1 .="<option value='".$bat['batiment']."'>".$bat['batiment']."</option>";
  }
  $this->content1 .="</select></br></br>
</form>";

if(isset($_GET["batiment"])){
  $batimentActuel = $_GET["batiment"];
}else{
$batimentActuel = 'A';
}
$this->content1.= "<h3> Batiement ".$batimentActuel."</h3>";
$this->content1.= "<ul>";
foreach ($logement as $log) {
  if($log['batiment']==$batimentActuel){
    $this->content1.="<li><a href='".$this->router->getLogementsURL($log['idLogements'])."'>".$log['logement']."</a></li>";
  }
}
$this->content1.= "</ul></div>";
