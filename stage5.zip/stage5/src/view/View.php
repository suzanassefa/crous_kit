<?php
require_once("Router.php");

class View{
  protected $router;
  protected $title;
  protected $content1;
  protected $content2;
  protected $menu;

  public function __construct(Router $router){
    $this->router = $router;
    $this->title = "";
    $this->content1 = "";
    $this->content2 = "";
    $this->menu = $this->getMenu();
  }

  public function render(){
    include_once("index.php");
  }

  public function getMenu(){
    return "<a href='".$this->router->getAccueilURL()."'>Accueil</a>
    <a href='".$this->router->getLogementsURL(3)."'>Logements</a>
    <a href='".$this->router->getBlanchisseriesURL()."'>Blanchisseries</a>
    <a href='".$this->router->getDeconnectionURL()."'>Deconnection</a>";
  }

  //***********************home page******************************//

  public function HomePageList($produits, $kits){
    $this->content1 = "<ul id='menu-accordeon'>
	     <li > <a href='#'>Produits</a>
		   <ul>";
    foreach ($produits as $ligne){
      $this->content1 .= "<li><a href='".$this->router->getAccueilProduitURL($ligne['idProduit'])."' >".$ligne['nomProduit']."</a></li>";
    }
    $this->content1 .= "</ul>
      </li>
      <li><a href='#'>Kits</a>
      <ul>";
    foreach ($kits as $ligne){
      //var_dump($ligne);
      $this->content1 .= "<li><a href='".$this->router->getAccueilKitURL($ligne['idKit'])."'>".$ligne['nomKit']." ".$ligne['nbPers']."</a></li>";
    }
    $this->content1 .= "</ul>
      </li>
      </ul>";
  }

  public function HomePageContentKit($createKits, $kit, $produits){
    $this->title = $kit['nomKit'];
    $this->content2 .="<table>
    <tr>
      <th>Produit qui sont dans ce kit</th>
      <td><ul>";
        foreach ($createKits as $ck) {
          if($kit['idKit']==$ck['kit']){
            foreach ($produits as $prd) {
              if($prd['idProduit']==$ck['produit']){
                $this->content2 .="<li>".$ck['quantite']." ".$prd['nomProduit']."-".$prd['nbPers']."</li>";
              }
            }
          }
        }
      $this->content2 .="</ul></td>
    </tr>
    <tr>
      <th>Tarif par semaine </th>
      <td>".$kit['tarif-semaine']."</td>
    </tr>
    <tr>
      <th>Tarif annuel </th>
      <td>".$kit['tarif-annuel']."</td>
    </tr>
    <tr>
      <th>descrition </th>
      <td>".$kit['descriptionK']."</td>
    </tr>";
    include_once('AccueilDetail.php');
    $this->content2 .="</table>";
    $this->content2 .= "<a href = '".$this->router->getAccueilModificationKitURL($kit['idKit'])."' class='button'>Gestion des kits</a>";
  }

  public function HomePageContentProduit($produit){
    $this->title = $produit['nomProduit'];
    $this->content2 .="<table>";
    include_once('AccueilDetail.php');
    $this->content2 .="<tr>
      <th>Quantité de Blanchisserie</th>
      <td></td>
    </tr>
    <tr>
      <th>Quantité en Destruction</th>
      <td></td>
    </tr>
    <tr>
      <th>Quantité Acheté</th>
      <td></td>
    </tr>
    </table>";
    $this->content2 .= "<a href = '".$this->router->getAccueilModificationProduitURL($produit['idProduit'])."' class='button'>Gestion des Produits</a>";
  }

  public function modifyAccueilKit($createKits, $kit, $produits){
    $this->content1 .= "<div class='content1createKit creation'><h3> Crée un nouveau Kit </h3><form method = 'POST' action='".$this->router->getAddKitURL()."'>
      <label for='nomKit'>Kit : </label><br/>
      <input type ='text' id='nomKit' name='nomKit'><br/>

      <label for='nbPers'>nombre de personne : </label><br/>
      <input type ='text' id='nbPers' name='nbPers'><br/>

      <label for='description'> Description : </label><br/>
      <input type ='text' id='description' name='description'><br/>

      <label for='tarif-semaine'> Tarif/semaine : </label><br/>
      <input type ='text' id='tarif-semaine' name='tarif-semaine'><br/>

      <label for='tarif-annuel'>Tarif annuel : </label><br/>
      <input type ='text' id='tarif-annuel' name='tarif-annuel'><br/>

      <input type='submit'  onclick='return confirm(\"Vous êtes sure de vouloir le ajouter cette kit ?\")' value='Ajouter un Kit'>
    </form></div>";

    $this->content2 .= "<div class='content1createKit' > <h3> Modifier ".$kit['nomKit']." </h3><form method = 'POST' action='".$this->router->getModifyKitURL($kit['idKit'])."'>
      <label for='nomKit'>Kit : </label><br/>
      <input type ='text' id='nomKit' name='nomKit' value='".$kit['nomKit']."'><br/>

      <label for='nbPers'>nombre de personne : </label><br/>
      <input type ='text' id='nbPers' name='nbPers' value=".$kit['nbPers']."><br/>

      <label for='description'> Description : </label><br/>
      <input type ='text' id='description' name='description' value='".$kit['descriptionK']."'><br/>

      <label for='tarif-semaine'> Tarif/semaine : </label><br/>
      <input type ='text' id='tarif-semaine' name='tarif-semaine' value=".$kit['tarif-semaine']."><br/>

      <label for='tarif-annuel'>Tarif annuel : </label><br/>
      <input type ='text' id='tarif-annuel' name='tarif-annuel' value=".$kit['tarif-annuel']."><br/>

      <input type='submit'  onclick='return confirm(\"Vous êtes sure de vouloir le modifier cette kit ?\")' value='Modifier un Kit'>
    </form>
  <div id='creationKit'>";
    $this->content2 .="<ul>";
    foreach ($createKits as $ck) {
      if($kit['idKit']==$ck['kit']){
        foreach ($produits as $prd) {
          if($prd['idProduit']==$ck['produit']){
            $this->content2 .="<li>".$ck['quantite']." ".$prd['nomProduit']."-".$prd['nbPers']."<a href='".$this->router->getDeleteProduitCKURL($prd['idProduit'], $kit['idKit'])."' onclick='return confirm(\"Vous êtes sure de vouloir suprimer ".$prd['nomProduit']." ?\")'><img id='img-logo-delete' src='https://dev-21707895.users.info.unicaen.fr/stage/skin/deleteLogo.png' alt='deleteLogo'></a></li>";
          }
        }
      }
    }
    $this->content2 .="</ul>

    <form method = 'POST' action='".$this->router->getCreateKitURL()."'>
    <input type='hidden' id='kit' name='kit' value='".$kit['idKit']."'>

      <select id='produit' name='produit' require>";
      foreach ($produits as $prd){
        $this->content2 .="<option value='".$prd['idProduit']."'>".$prd['nomProduit']."  ".$prd['nbPers']."</option>";
      }
      $this->content2 .="</select>
      <label for='quantite'>Quantité : </label>
      <select id='quantite' name='quantite' require>
        <option >1</option>
        <option >2</option>
        <option >3</option>
      </select><br/><br/>
      <input type='submit'  onclick='return confirm(\"Vous êtes sure de vouloir le ajouter ce Produit?\")' value='Ajouter un Produit'>
    </form></div>
    <a href='".$this->router->getDeleteKitURL($kit['idKit'])."' onclick='return confirm(\"Vous êtes sure de vouloir suprimer ".$kit['nomKit']." ?\")'>SUPRIMER</a>
    </div>";

   }

   public function modifyAccueilProduit($produit){
     $this->content1 .= "<div class='content1createKit  creation' ><h3> Crée un nouveau Poduit </h3><form method = 'POST' action='".$this->router->getAddProduitURL()."'>
        <label for='nomProduit'>Produit : </label><br/>
        <input type ='text' id='nomProduit' name='nomProduit'><br/>

       <label for='nbPers'>nombre de personne : </label><br/>
       <input type ='text' id='nbPers' name='nbPers'><br/>

       <label for='descriptionP'> Tarif/semaine : </label><br/>
       <input type ='text' id='descriptionP' name='tarif-semaine'><br/>

       <label for='type'>Type : </label><br/>
       <input type ='text' id='type' name='type'><br/>

       <input type='submit' onclick='return confirm(\"Vous êtes sure de vouloir le ajouter ce Produit ?\")' value='Ajouter un Produit'>
     </form>
     </div>";

     $this->content2 .= "<div class='content1createKit' > <h3> Modifier ".$produit['nomProduit']." </h3><form method = 'POST' action='".$this->router->getAddKitURL()."'>
     <label for='nomProduit'>Produit : </label><br/>
     <input type ='text' id='nomProduit' name='nomProduit'><br/>

    <label for='nbPers'>nombre de personne : </label><br/>
    <input type ='text' id='nbPers' name='nbPers'><br/>

    <label for='descriptionP'> Tarif/semaine : </label><br/>
    <input type ='text' id='descriptionP' name='tarif-semaine'><br/>

    <label for='type'>Type : </label><br/>
    <input type ='text' id='type' name='type'><br/>

       <input type='submit'  onclick='return confirm(\"Vous êtes sure de vouloir le modifier cette kit ?\")' value='Modifier ce Produit'>
     </form>
     <a href='".$this->router->getDeleteProduitURL($produit['idProduit'])."' onclick='return confirm(\"Vous êtes sure de vouloir suprimer ".$produit['nomProduit']." ?\")'>SUPRIMER</a>
     </div>";
   }

//***************************Logement*********************//
  public function LogementList($batiments, $logement){

    include_once("LogementList.php");
  }

  public function LogementContent($kits, $etudiants, $prets, $idLog){
    include_once("LogementContent.php");
  }

  public function pretFormualire($logement, $etudiant){
    include_once("FormulairePret.php");
  }
  public function pretModificationForm($pretsLigne, $logement, $etudiant){
    include_once("ModificationPret.php");
  }

  public function etudiantFormulaire($id){
    $this->content2 .=   "<form method = 'POST' action='".$this->router->getSaveEtudiantURL($id)."'>
    <label for='nom'>Nom:</label>
    <input type ='text' id='nom' name='nom'>
    </br></br>
    <label for='prenom'>Prenom:</label>
    <input type ='text' id='prenom' name='prenom'>
    </br></br>
    <label for='num-tel'>Numeros de Téléphone:</label>
    <input type ='text' id='num-tel' name='num-tel'>
    </br></br>
   <input type='submit' value='Submit'>
   </form>";
  }

  ////////**************success failure********************////
  public function displaySuccess2Logement($id){
      $this->router->PostRedirect($this->router->getLogementsURL($id));
  }
  public function displaySuccess2Accueil(){
    $this->router->PostRedirect($this->router->getAccueilURL());
  }

  public function displaySuccess2AccueilModification(){
    $this->router->PostRedirect($this->router->getAccueilURL());
  }

  public function makeDebugPage($variable) {
		$this->title = "Debug";
		$this->content1 = "<pre>".htmlspecialchars(var_export($variable, true)).'</pre>';
	}
}
