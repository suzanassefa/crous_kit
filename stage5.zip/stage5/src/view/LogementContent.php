<?php
foreach ($etudiants as $etu) {
  $this->content2 .=
      "  <div class='section'><table>
          <caption>".$etu['nom']." ".$etu['prenom']."</caption>
          <tr>
            <th>Nom du kit</th>
            <th>Date de pet</th>
            <th>Mantant facturé</th>
            <th>Payeur</th>
            <th>Payement fait</th>
            <th>Date de départ prévu </th>
            <th>Observation</th>
            <th>Date de Retour</th>
            <th>Etat</th>
          </tr>";

          foreach ($prets as $p) {
            if($p['etudiant'] == $etu['idEtudiant']){
              $this->content2.="<tr>";
              foreach($kits as $k){
                if($p['kit']==$k['idKit']){
                  $nomKit = $k['nomKit'];
                  $nbPers = $k['nbPers'];
                }
              }
              $this->content2.="<td>".$nomKit."-".$nbPers."</td>";
              $phpdateP = strtotime( $p['datePret'] );
              $mysqldateP = date( 'm/d/y', $phpdateP );

              $phpdateD = strtotime( $p['dateDepartPrevu'] );
              $mysqldateD = date( 'm/d/y', $phpdateD );

              $this->content2.=" <td>".$mysqldateP."</td>
                <td>".$p['montantFacturer']."</td>
                <td>".$p['Payeur']."</td>
                <td>".$p['estPayer']."</td>
                <td>".$mysqldateD."</td>
                <td>".$p['observation']."</td>
                <td> </td>
                <td> </td>
                <td><a href = '".$this->router->getModifyPretURL($p['idPret'], $idLog)."'>Modifier</a></td>
                <td><a href = '".$this->router->getDeletePretURL($p['idPret'], $idLog)."' onclick='return confirm(\"Vous êtes sure de vouloir le suprimer le ".$nomKit."-".$nbPers." de ".$etu['nom']." ".$etu['prenom']."?\")'>Suprimer</a></td>
              </tr>";
          }
        }

        $this->content2.= "</table>";
        $this->content2 .= "<a href='".$this->router->getPretFormulaireURL($etu['idEtudiant'], $idLog)."'> Ajouter un Kit</a> ";
        $this->content2 .= "<a href='".$this->router->getDeleteEtudiantURL($etu['idEtudiant'], $idLog)."' onclick='return confirm(\"Vous êtes sure de vouloir le suprimer ".$etu['nom']." ".$etu['prenom']." ainsi que ces données ?\")'>Suprimer l'étudiant et ces donnée</a></div>";

}
$this->content2 .= "<br/><br/><a href='".$this->router->getEtudiantFormulaireURL($idLog)."'> Ajouter un Etudiant</a> ";
