<?php

//require_once("model/Logements.php");
require_once("model/EtudiantsBuilder.php");
require_once("model/PretsBuilder.php");
require_once("view/View.php");

class ControlLogements{
  protected $view;
  protected $logementsStorage;
  protected $etudiantsStorage;
  protected $pretsStorage;
  protected $kitsStorage;

  public function __construct(View $view, LogementsStorage $logementsStorage, EtudiantsStorage $etudiantsStorage, PretsStorage $pretsStorage, KitsStorage $kitsStorage){
    $this->view = $view;
    $this->logementsStorage = $logementsStorage;
    $this->etudiantsStorage = $etudiantsStorage;
    $this->pretsStorage = $pretsStorage;
    $this->kitsStorage = $kitsStorage;
  }

  public function showLogement($id){
    $this->view->LogementList($this->logementsStorage->readBatiments(), $this->logementsStorage->readAll());

    $etudiants= $this->etudiantsStorage->readEtudiantParLogement($id);
    $prets= $this->pretsStorage->readPretParEtudiant($id);
    $kits = $this->kitsStorage->readAllKit();
    $retour = $this->pretsStorage->readDistinctRetour();
    $isReturned =   $this->pretsStorage->isReturned();
    $this->view->LogementContent($kits, $etudiants,$prets, $id, $retour, $isReturned);
  }

  public function pretFormualire($idEtu, $idLog){
    $etudiant = $this->etudiantsStorage->readEtudiant($idEtu);
    $logement = $this->logementsStorage->read($idLog);
    $kits = $this->kitsStorage->readAllKit();
    if($etudiant !== NUll and $logement !== NULL){
      $kits = $this->kitsStorage->readAllKit();
      $this->view->pretFormualire($logement, $etudiant, $kits);
    }
  }

  public function saveNewPret($idLog, array $data){
    $buildPret = new PretsBuilder($data);
    if($buildPret->isValid()){
      $pret = $buildPret->newPret($data);
      $this->pretsStorage->addPret($pret);
      $this->kitsStorage->pretCalculStockKit($pret->getKit(), $pret->getLieu(), 'soustraction');
      $this->view->displaySuccess2Logement($idLog);
    }else{
      print("erreur");
      //$this->view->displayNewPretfailure();
    }
  }

  public function modifyPrets($id, $idLog){
    $pretLigne = $this->pretsStorage->read($id);
    $etudiant = $this->etudiantsStorage->readEtudiant($pretLigne['etudiant']);
    $logement = $this->logementsStorage->read($idLog);
    $kits = $this->kitsStorage->readAllKit();
    if($pretLigne !== Null and $etudiant !== NUll and $logement !== NULL and $logement !== NULL){
      $this->view->pretModificationForm($pretLigne, $logement, $etudiant, $kits);
		}
		//else{$this->view->makeUnexpectedErrorPage();}
  }

  public function confirmModification($idLog, array $data, $id){
    $pretLigne = $this->pretsStorage->read($id);
    $buildPret = new PretsBuilder($data);
    if($buildPret->isValid()){
      if($pretLigne['lieu'] !== $data['lieu']){
        $this->kitsStorage->pretCalculStockKit($data['kit'], $data['lieu'], 'soustraction');
        $this->kitsStorage->pretCalculStockKit($data['kit'], $pretLigne['lieu'], 'addition');
      }
      $pret = $buildPret->newPret($data);
      $this->pretsStorage->update($pret, $id);
      $this->view->displaySuccess2Logement($idLog);
    }
  }
  //else{$this->view->displayUpdateFailure();}

  public function return($data, $idP, $idL){
    $returnLigne = $this->pretsStorage->readReturnPret($idP);
    $buildPret = new PretsBuilder($data);
    if($returnLigne === false){
      if($buildPret->isValid()){
        $retour = $buildPret->pretWithRetour($data);
        $produits = $this->kitsStorage->readCreateKit($retour->getKit());
        $this->pretsStorage->addRetour($retour, $idP, $produits);
        $this->view->displaySuccess2Logement($idL);
      }else{
        print("erreur");
        //$this->view->displayNewPretfailure();
      }
    }else{
      if($buildPret->isValid()){
        $retour = $buildPret->pretWithRetour($data);
        $produits = $this->kitsStorage->readCreateKit($retour->getKit());
        $this->pretsStorage->updateRetour($retour, $idP, $produits);
        $this->view->displaySuccess2Logement($idLog);
      }else{
        print("erreur");
        //$this->view->displayNewPretfailure();
      }

    }

  }

  public function deletePret($pret, $idLog){
    $idKit = $this->pretsStorage->read($pret);
    if($this->pretsStorage->delete($pret)){
      $this->kitsStorage->pretCalculStockKit($idKit['kit'],'LCR', 'addition');
      $this->view->displaySuccess2Logement($idLog);
    }else{
      $this->view->makeDebugPage("erreur de supression");
    }
  }
/////////////////////:Etudiant///////////////////////////////
  public function saveNewEtudiant($id, $data){
    $buildEtudiant = new EtudiantsBuilder($data);
    if($buildEtudiant->isValid()){
      $etudiant = $buildEtudiant->newEtudiant($data, $id);
      $this->etudiantsStorage->addEtudiant($etudiant);
      $this->view->displaySuccess2Logement($id);
    }else{
      print("erreur");
      //$this->view->displayNewPretfailure();
    }
  }

  public function deleteEtudiant($id, $idLog){
    $p = $this->pretsStorage->deleteParEtudiant($id);
    $e = $this->etudiantsStorage->delete($id);
    if( $e and $p){
      $this->view->displaySuccess2Logement($idLog);
    }else{
      $this->view->makeDebugPage("erreur de supression");
    }
  }
}
