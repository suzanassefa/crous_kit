<?php

//require_once("model/Logements.php");
require_once("model/BlanchisserieBuilder.php");


class ControlBlanchisserie{
  protected $view;
  protected $pretsStorage;
  protected $produitsStorage;
  protected $blanchisserieStorage;

  public function __construct(View $view, PretsStorage $pretsStorage, ProduitsStorage $produitsStorage, BlanchisserieStorage $blanchisserieStorage){
    $this->view = $view;
    $this->produitsStorage = $produitsStorage;
    $this->pretsStorage = $pretsStorage;
    $this->blanchisserieStorage = $blanchisserieStorage;
  }

  public function blanchisserieContent(){
    $produit = $this->produitsStorage->readAll();
    $mois = array('01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12');
    foreach($mois as $m){
      $blanchis = $this->blanchisserieStorage->readMonth($m);
      if(sizeof($blanchis)>0){
        switch ($m) {
          case '01':
            $month = "Janvier";
            break;
          case '02':
            $month = "Février";
            break;
          case '03':
            $month = "Mars";
            break;
          case '04':
            $month = "Avril";
            break;
          case '05':
            $month = "Mai";
            break;
          case '06':
            $month = "Juin";
            break;
          case '07':
            $month = "Juillet";
            break;
          case '08':
            $month = "Août";
            break;
          case '09':
            $month = "Septembre";
            break;
          case '10':
            $month = "Octobre";
            break;
          case '11':
            $month = "Novembre";
            break;
          case '12':
            $month = "Decembre";
            break;
        }
        $this->view->blanchisserieContent($blanchis, $month, $produit);
      }

    }
    //$blanchis = $this->blanchisserieStorage->readAll();
  //  $this->view->blanchisserieContent($blanchis);
  }

  public function formulaireDepart(){
    $produit = $this->produitsStorage->readAll();
    $this->view->formulaireDepart($produit);
  }

  public function saveDepart($data){
    $buildBlanchisserie = new BlanchisserieBuilder($data);
    if($buildBlanchisserie->isValid()){
      $blanchisserie = $buildBlanchisserie->departBlanchisserie($data);
      $this->blanchisserieStorage->addBlanchisserie($blanchisserie);
      $this->view->displaySuccess2Blanchisserie();
    }else{
      print("erreur");
      //$this->view->displayNewPretfailure();
    }
  }

  public function deleteBlanchis($idB){
    if($this->blanchisserieStorage->delete($idB)){
      $this->view->displaySuccess2Blanchisserie();
    }else{
      $this->view->makeDebugPage("erreur de supression");
    }
  }

  public function modifyBlanchis($id){
    $produit = $this->produitsStorage->readAll();
    $blanchisserie = $this->blanchisserieStorage->read($id);
    if($blanchisserie !== Null ){
      $this->view->modifyBlanchis($blanchisserie, $produit);
    }
    //else{$this->view->makeUnexpectedErrorPage();}
  }

  public function confirmModificationBlanche($data, $id){
    $buildBlanch = new BlanchisserieBuilder($data);
    if($buildBlanch->isValid($data)){
      $blanch = $buildBlanch->departBlanchisserie($data);
      $this->blanchisserieStorage->updateBlanch($blanch, $id);
      $this->view->displaySuccess2Blanchisserie();
    }else{
      $variable = "erreur";
      $this->view->makeDebugPage($variable);
      //$this->view->displayNewPretfailure();
    }
  }

  public function retourBlanche($data, $id){
    $buildBlanch = new BlanchisserieBuilder($data);
    if($buildBlanch->isValidRetour($data)){
      $blanch = $buildBlanch->retourBlanchisserie($data);
      if($this->blanchisserieStorage->retourBlanch($blanch, $id)){
        if($this->produitsStorage->addToStock($blanch->getProduit(), $blanch->getQuantiteRetour(), $blanch->getLieu())){
          $this->view->displaySuccess2Blanchisserie();
        }
      }
    }else{
      $variable = "erreur";
      $this->view->makeDebugPage($variable);
      //$this->view->displayNewPretfailure();
    }
  }


}
