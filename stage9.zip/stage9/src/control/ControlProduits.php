<?php

require_once("model/ProduitsStorage.php");
require_once("model/KitsBuilder.php");
require_once("model/ProduitsBuilder.php");
require_once("model/StockTotalBuilder.php");
require_once("view/View.php");

class ControlProduits{
  protected $view;
  protected $produitsStorage;

  public function __construct(View $view, ProduitsStorage $produitsStorage, KitsStorage $kitsStorage, StockTotalStorage $stockTotalStorage, PretsStorage $pretsStorage, BlanchisserieStorage $blanchisserieStorage){
    $this->view = $view;
    $this->produitsStorage = $produitsStorage;
    $this->kitsStorage = $kitsStorage;
    $this->pretsStorage = $pretsStorage;
    $this->stockTotalStorage = $stockTotalStorage;
    $this->blanchisserieStorage = $blanchisserieStorage;
  }

  // ***************page Accueil des kits************//////////

  //affiche la liste des kits a gauche

  public function showListKit(){
    $this->view->HomePageListKit($this->produitsStorage->readAll(), $this->kitsStorage->readAllKit());
  }


  // affiche le contenue avec des information pour chaque kit

  public function kits($id){
    $stockL = $this->stockTotalStorage->readAll();
    $kit = $this->kitsStorage->readKit($id);
    $createKits = $this->kitsStorage->readAllCreateKit($kit['idKit']);
    $produits = $this->produitsStorage->readAll();
    $countStockPret = $this->pretsStorage->countStockPret();
    $this->view->HomePageContentKit($createKits, $kit,$produits,$stockL, $countStockPret);
  }

  /// formulaire pour modifier les données du kit selectionner

  public function modifyAccueilKit($id){
    //$createKits = $this->kitsStorage->readAllCreateKit();
    $kits = $this->kitsStorage->readAllKit();
    //$produits = $this->produitsStorage->readAll();
    $kit = $this->kitsStorage->readKit($id);
    $createKits = $this->kitsStorage->readAllCreateKit($kit['idKit']);
    $produits = $this->produitsStorage->readAll();
    $this->view->modifyAccueilKit($createKits, $kits, $kit,$produits);
  }

/// creé une association des produit afin de crée un produit
  public function createKit($data){
    if($data['produit'] !== ""){
      $this->kitsStorage->createKit($data);
      $this->view->success2AccueilKit($data['kit'], "les produit du kit est bien mis à jour.");
    }else{
      $this->view->makeDebugPage("Il y a un erreur sur la creation du kit, veillez recommencer.");
    }
  }

  ////ajouter un type kit dans la base de donée
  public function addKit($data){
    $buildKit = new KitsBuilder($data);
    if($buildKit->isvalid($data)){
      $kit = $buildKit->newKit($data);
      $this->kitsStorage->addKit($kit);
      $this->view->success2AccueilKit(1, "Le kit a bien été enregistrer.");

    }else{
      $variable = "Le kit n'as pas été crée suite a une erreur. Veillez remplir les deux première champ.";
      $this->view->makeDebugPage($variable);
      //$this->view->displayNewPretfailure();
    }
  }

  public function deleteKit($id){
    if($this->kitsStorage->deleteKit($id)){
      $this->view->success2AccueilKit(1, "Le kit a bien été suprimer.");
    }
    else{
      $variable = "erreur : le kit n'as pas été supprimer.";
      $this->view->makeDebugPage();
    }
  }

  public function modifyKit($data, $id){
    $buildKit = new KitsBuilder($data);
    if($buildKit->isValid($data)){
      $kit = $buildKit->newKit($data);
      $this->kitsStorage->updateKit($kit, $id);
      $this->view->displaySuccess2AccueilModification();
    }else{
      $variable = "erreur";
      $this->view->makeDebugPage($variable);
      //$this->view->displayNewPretfailure();
    }
  }

  //////****************Produit***********//////////

  public function showListProduit(){
    $this->view->HomePageListProduit($this->produitsStorage->readAll(), $this->kitsStorage->readAllKit());
  }

  public function produits($id){
    $stockL = $this->stockTotalStorage->readAll();
    $produit = $this->produitsStorage->read($id);
    $countBlanchisserie = $this->blanchisserieStorage->countBlanchisserie();
    $this->view->HomePageContentProduit($produit, $stockL, $countBlanchisserie);
  }


  public function modifyAccueilProduit($id){
    $produit = $this->produitsStorage->read($id);
    $this->view->modifyAccueilProduit($produit);
  }

  public function miseAJourProduit($id){
    $produit = $this->produitsStorage->read($id);
    $this->view->miseAJourProduit($produit);
  }


  public function deleteProduitCK($idP, $idK){
    if($this->kitsStorage->deleteCreateKit($idP, $idK)){
      $this->view->displaySuccess2AccueilModification();
    }
    else{
      $variable = "erreur";
      $this->view->makeDebugPage();
      //$this->view->makeUnexpectedErrorPage() ;
    }
  }




    public function addProduit($data){
      $buildProduit = new ProduitsBuilder($data);
      if($buildProduit->isvalid($data)){
        $produit = $buildProduit->newProduit($data);
        $this->produitsStorage->addProduit($produit);
        $this->view->displaySuccess2AccueilModification();
      }else{
        $variable = "erreur";
        $this->view->makeDebugPage($variable);
        //$this->view->displayNewPretfailure();
      }
    }



    public function deleteProduit($id){
      if($this->produitsStorage->deleteProduit($id)){
        $this->view->displaySuccess2AccueilModification();
      }
      else{
        $variable = "erreur ";
        $this->view->makeDebugPage();
        //$this->view->makeUnexpectedErrorPage() ;
      }
    }



    public function modifyProduit($data, $id){
      $buildProduit = new ProduitsBuilder($data);
      if($buildProduit->isValid($data)){
        $produit = $buildProduit->newProduit($data);
        $this->produitsStorage->updateProduit($produit, $id);
        $this->view->displaySuccess2AccueilModification();
      }else{
        $variable = "erreur";
        $this->view->makeDebugPage($variable);
        //$this->view->displayNewPretfailure();
      }
    }

    //Inventaire, Achat, Destruction

    public function stockTotal($data, $idP){
      $buildStockL = new StockTotalBuilder($data);
      if($buildStockL->isvalid($data)){
        $stockL = $buildStockL->newStockTotal($data, $idP);
        $this->stockTotalStorage->addStockL($stockL);
        if($stockL->getType() === 'Achat'){
          $this->produitsStorage->addToStock($stockL->getProduit(), $stockL->getQuantite(), $stockL->getLieu());
        }
        $this->view->displaySuccess2AccueilModification();
      }else{
        $variable = "erreur";
        $this->view->makeDebugPage($variable);
        //$this->view->displayNewPretfailure();
      }
    }

    public function creationKit($data){
      $res2 = $this->kitsStorage->selectProduits($data['kit']);
      foreach ($res2 as $r){
        $res3 = $this->produitsStorage->calcul1a($data['stockOrigine'], $r['produit']);
        $newLieu = $res3[$data['stockOrigine']] - ($r['quantite']*$data['quantite']);
        $newStockTotal =  $res3['StockTotal'] - ($r['quantite']*$data['quantite']);
        $this->produitsStorage->calcul1b($data['stockOrigine'], $r['produit'], $newLieu, $newStockTotal);
      }
      if ($this->kitsStorage->additionStockKit($data)){
          $this->view->displaySuccess2AccueilModification();
       }
    }

    public function deplacerKit(){
      $kits = $this->kitsStorage->readAllKit();
      $this->view->deplacerKit($kits);
    }

    public function deplacerProduit(){
      $produits = $this->produitsStorage->readAll();
      $this->view->deplacerProduit($produits);
    }

    public function formulaireCreationKit(){
      $kits = $this->kitsStorage->readAllKit();
      $this->view->formulaireCreationKit($kits);
    }

    public function moveProduit($data){
      if($data["quantite"] !=  ""){
        if($this->produitsStorage->moveProduit($data)){
          $this->view->displaySuccess2AccueilModification();
        }
      }
    }
    public function moveKit($data){
      if($data["quantite"] !=  ""){
        if($this->kitsStorage->moveKit($data)){
          $this->view->displaySuccess2AccueilModification();
        }
      }
    }
}
