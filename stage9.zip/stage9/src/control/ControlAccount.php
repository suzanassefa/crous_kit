<?php

require_once("view/View.php");
require_once("model/AccountBuilder.php");



class ControlAccount{
	protected $view;
	protected $accountstorage;


	public function __construct(View $view, AccountStorage $accountstorage) {
		$this->view = $view;
		$this->accountstorage =$accountstorage;
	}

  public function connectionPage(array $data){

    $accountBuilder = new AccountBuilder($data);
    if($accountBuilder->isValid()){
      $t = $accountBuilder->connecting($this->accountstorage);
    }
    if($accountBuilder->isUserConnected()){
      $this->view->displayConnectionSucess();
    }
    else{
      $this->view->dispalayConnectionFailure();
    }
  }

  public function creatAccount(array $data){
    $AccountBuilder = new AccountBuilder($data);
    if($AccountBuilder->inscriptionValid()){
      $account = $AccountBuilder->inscrire();
      if($this->accountstorage->cheakIfUserExistInDB($account)){
        $this->accountstorage->addToDB($account);
        $this->view->displayInscriptionSucess();

      }
      else{
        $this->view->dispalayLoginExiste();
      }
    }else{
      $this->view->dispalayConnectionFailure();

    }
  }

	public function deconnectionPage(){
		$_SESSION['user'] = null;
    if($_SESSION['user'] !== null){
      $this->view->displayDeconnectionFailure();
		}else{
      $this->view->displayDeconnectionSucess();

		}
	}

		//voir les liste des utilisateur enregistrer dans la base de donnée
	public function Inscription(){
			$this->view->listEtInscription($this->accountstorage->readAll());
		}

		//suppression une fois confirmé
	public function deleteUser($id){
		if($this->accountstorage->delete($id)){

			$this->view->displayUserDeletionSucess();
		}
		else{
			$this->view->makeUnexpectedErrorPage();
		}
	}

}



/**
	//L'administrateur peut modifier les données, il peut faire qu'une seul modification : permettre au utilisateur d'avoir le statut admin
		//redirection vers une page de confirmation
	public function askUserModification($id){
		$userLigne = $this->accountstorage->read($id);
		if($userLigne == Null){
			$this->view->makeUnexpectedErrorPage();
		}
		else{
			$this->view->makeUpdateUserPage($userLigne, $id);
		}
	}

	//modification se fait
	public function ModifyUser($id){
		if($this->accountstorage->update($id)){

			$this->view->displayUserModifySucess();
		}
		else{
			$this->view->makeUnexpectedErrorPage();
		}
	}**/
