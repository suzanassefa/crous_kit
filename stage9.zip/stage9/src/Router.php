<?php
session_name("gestionKits");
session_start();
if(!isset($_SESSION['user'])){
	$_SESSION['user'] = null ;
}
require_once("model/ProduitsStorage.php");
require_once("model/LogementsStorage.php");
require_once("model/EtudiantsStorage.php");
require_once("model/PretsStorage.php");
require_once("model/BlanchisserieStorage.php");

require_once("view/View.php");
require_once("view/AdminView.php");
require_once("view/UserView.php");

require_once("control/ControlProduits.php");
require_once("control/ControlLogements.php");
require_once("control/ControlAccount.php");
require_once("control/ControlBlanchisserie.php");

class Router{
    protected $view;
    protected $control;
    protected $action;
    protected $id;

    public function _contruct(){
      $action = null;
      $id = 1;
    }

    public function main( ProduitsStorage $produitsStorage, LogementsStorage $logementsStorage, EtudiantsStorage $etudiantsStorage, PretsStorage $pretsStorage, KitsStorage $kitsStorage, StockTotalStorage $stockTotalStorage, AccountStorage $comptesStorage, BlanchisserieStorage $blanchisserieStorage){
      //$this->view = new View($this);

      //feedback
		$feedback = key_exists('feedback', $_SESSION) ? $_SESSION['feedback'] : '';
    $_SESSION['feedback'] = '';

//view adapté a l'utilsateur
      if($_SESSION['user']==null){
        $this->view= new View($this,$feedback);
      }else{

        if($_SESSION["user"]['statut']=="user" ){
          $this->view= new UserView($this,$_SESSION["user"],$feedback);
        }
        if($_SESSION["user"]['statut']== "admin" ){
          $this->view= new AdminView($this,$_SESSION["user"],$feedback);
        }
      }

      $this->controlP = new ControlProduits($this->view, $produitsStorage, $kitsStorage, $stockTotalStorage, $pretsStorage, $blanchisserieStorage);
      $this->controlL = new ControlLogements($this->view, $logementsStorage, $etudiantsStorage, $pretsStorage, $kitsStorage);
			$this->controlA = new ControlAccount($this->view, $comptesStorage);
      $this->controlB = new ControlBlanchisserie($this->view, $pretsStorage, $produitsStorage, $blanchisserieStorage);

      //traitement de PATH_INFO

        if(key_exists("PATH_INFO", $_SERVER)){
        	$tab = explode('/', $_SERVER["PATH_INFO"]);
        	$taille=count($tab);
        	//print($tab[1]);
        	if($taille === 2){
        		$action = htmlspecialchars($tab[1]);
        	}if($taille >= 3){
        		$id = htmlspecialchars($tab[2]);
        		$action = htmlspecialchars($tab[1]);
            if($taille===4){
              $otherId = htmlspecialchars($tab[3]);
            }
        	}
        }else{
          $action = "accueil";
        }



//var_dump($_SESSION['user']);
      try{
        switch ($action){

					// la première page index.php
					//soit affiche une formulaire de fann_get_total_connections
					//soit un utilisateur est déja connecter, renvoie donc vers la première produit de la page produit
        case "accueil":
          if($_SESSION['user']==null){
            $this->view->makeLoginFormPage();
          }else{
            $this->controlP->showListProduit();
            $this->controlP->produits(1);
          }
          break;


/////////////*************la page de Kit*******************///////////////
					// Affiche la liste des Kit et sont contenue
        case "kits":
          $this->controlP->showListKit();
          $this->controlP->kits($id);
          break;

					////formulaire de la création d'un nouveau kit
				case "newKit":
					$this->view->newKit();
					break;
				// formulaire de modification du kit selectionner
				case "modifyAccueilKit":
          $this->controlP->modifyAccueilKit($id);
          break;
					//// ajouter le kit du formulaire vers la base de donnée
				case 'addKit':
					if($_SERVER["REQUEST_METHOD"] === "POST"){
						$this->controlP->addKit($_POST);
					}
					break;
				case 'associationKit':
					if($_SERVER["REQUEST_METHOD"] === "POST"){
						$this->controlP->createKit($_POST);
					}
					break;
				case 'deleteKit':
					$this->controlP->deleteKit($id);
					break;
	//la///////////////////////////////////////////////////////////////:
				case 'modifyKit':
					if($_SERVER["REQUEST_METHOD"] === "POST"){
						$this->controlP->modifyKit($_POST, $id);
					}
					break;
				case "creationKit":
          if($_SERVER["REQUEST_METHOD"] === "POST"){
            $this->controlP->creationKit($_POST);
          }
          break;
				case 'deleteProduitCK':
					$this->controlP->deleteProduitCK($id, $otherId);
					break;


					case "deplacerKit";
	          $this->controlP->deplacerKit();
	          break;

					case "moveKit":
						if($_SERVER["REQUEST_METHOD"] === "POST"){
							$this->controlP->moveKit($_POST);
						}
						break;

				//////////////la page de produit
        case 'produits':
          $this->controlP->showListProduit();
          $this->controlP->produits($id);
          break;
        case "newProduit":
          $this->view->newProduit();
          break;

        case "modifyAccueilProduit":
          $this->controlP->modifyAccueilProduit($id);
          break;
				case "MiseAJourProduit":
					$this->controlP->miseAJourProduit($id);
					break;
				case 'addProduit':
					if($_SERVER["REQUEST_METHOD"] === "POST"){
						$this->controlP->addProduit($_POST);
					}
					break;
				case 'deleteProduit':
					$this->controlP->deleteProduit($id);
					break;
				case 'modifyProduit':
          if($_SERVER["REQUEST_METHOD"] === "POST"){
            $this->controlP->modifyProduit($_POST, $id);
          }
          break;
				case "deplacerProduit";
					$this->controlP->deplacerProduit();
					break;
				case "creationProduit":
					$this->controlP->formulaireCreationKit();
					break;
				case "moveProduit":
					if($_SERVER["REQUEST_METHOD"] === "POST"){
						$this->controlP->moveProduit($_POST);
					}
					break;

				////////////Logement ou Pret
        case "logements":
          $this->controlL->showLogement($id);
          break;
					case "pretFormulaire":
	          $this->controlL->pretFormualire($id, $otherId);
	          break;
	        case "savePret":
	          if($_SERVER["REQUEST_METHOD"] === "POST"){
	            $this->controlL->saveNewPret($id, $_POST);
	          }
	          break;
	        case "modifyPret":
	          $this->controlL->modifyPrets($id, $otherId);
	          break;
	        case "confirmModificationPret":
	          if($_SERVER["REQUEST_METHOD"] === "POST"){
						    $this->controlL->confirmModification($otherId, $_POST, $id);
					  }
	          break;
				case "return":
				if($_SERVER["REQUEST_METHOD"] === "POST"){
						$this->controlL->return($_POST, $id, $otherId);
				}
        case "deletePret":
          $this->controlL->deletePret($id, $otherId);
          break;


///////////////////Etudiant///////////////
        case 'etudiantFormulaire':
          $this->view->etudiantFormulaire($id);
          break;
        case 'saveEtudiant':
          if($_SERVER["REQUEST_METHOD"] === "POST"){
            $this->controlL->saveNewEtudiant($id, $_POST);
          }
          break;
        case 'deleteEtudiant':
          $this->controlL->deleteEtudiant($id, $otherId);
          break;


///////stockTotal//////////////////
        case "stockTotal":
          if($_SERVER["REQUEST_METHOD"] === "POST"){
            $this->controlP->stockTotal($_POST, $id);
          }
          break;


/////////:////////account////////

        case "connectionSucess":
          if($_SERVER["REQUEST_METHOD"] === "POST"){
            $this->controlA->connectionPage($_POST);
          }
          break;
        case "inscription":
  				$this->controlA->Inscription();
  				break;
        case "inscriptionSucess":
          if($_SERVER["REQUEST_METHOD"] === "POST"){
            $this->controlA->creatAccount($_POST);
          }
          break;
        case "deconnection":
          $this->controlA->deconnectionPage();
          break;
				case "supprimerUser":
					$this->controlA->deleteUser($id);
					break;

//////////////blanchisserie////////////
				case "blanchisseries":
					$this->view->BlanchisserieMiseEnPage();
					$this->controlB->BlanchisserieContent();
					break;
				case "formulaireDepart":
					$this->controlB->formulaireDepart();
					break;
				case "saveDepart":
					if($_SERVER["REQUEST_METHOD"] === "POST"){
						$this->controlB->saveDepart($_POST);
					}
					break;
				case "deleteBlanchis":
					$this->controlB->deleteBlanchis($id);
					break;
				case "modifyBlanchis":
					$this->controlB->modifyBlanchis($id);
					break;
				case "confirmModificationBlanche":
					if($_SERVER["REQUEST_METHOD"] === "POST"){
						$this->controlB->confirmModificationBlanche($_POST, $id);
					}
					break;
				case "retourBlanche":
					if($_SERVER["REQUEST_METHOD"] === "POST"){
						$this->controlB->retourBlanche($_POST, $id);
					}
					break;

  /////////////default
        default:
          $variable = "erreur au niveau du default";
          //makeDebugPage
          break;
        }
      }catch(Exception $e){
        $variable = "erreur au niveau du catch";
        //makeDebugPage
      }
      $this->view->render();
    }

  public function getAccueilURL(){
    return "https://dev-21707895.users.info.unicaen.fr/stage/index.php";
    //return "http://srv-phpmysql.in.crous-normandie.fr:8080/index.php";
  }
  public function getStyleURL(){
    return "https://dev-21707895.users.info.unicaen.fr/stage/skin/main.css";
    //return "http://srv-phpmysql.in.crous-normandie.fr:8080/skin/main.css";
  }

  public function getJsURL(){
    return "https://dev-21707895.users.info.unicaen.fr/stage/skin/java.js";
    //return "http://srv-phpmysql.in.crous-normandie.fr:8080/skin/java.js";
  }

  ///////////connexion Page////////////////////////

  public function getConnectionReussiURL(){
    return $this->getAccueilURL()."/connectionSucess";
  }
  public function getInscriptionURL(){
		return $this->getAccueilURL()."/inscription";
	}
  public function getInscriptionSucessURL(){
    return $this->getAccueilURL()."/inscriptionSucess";
  }
  public function getDeconnectionURL(){
    return $this->getAccueilURL()."/deconnection";
  }
	public function getUserAskDeletionURL($id){
		return $this->getAccueilURL()."/supprimerUser/".$id;
	}


  /////////////////////Kit//////////////////////////
  public function getAccueilKitURL($idKit){
    return $this->getAccueilURL()."/kits/".$idKit;
  }

	public function getNewKitURL(){
		return $this->getAccueilURL()."/newKit";
	}

	public function getCreationKitURL(){
		return $this->getAccueilURL()."/creationKit";
	}

	public function getAccueilModificationKitURL($id){
		return $this->getAccueilURL()."/modifyAccueilKit/".$id;
	}

  public function getModifyKitURL($id){
    return $this->getAccueilURL()."/modifyKit/".$id;
  }

	public function getAddKitURL(){
		return $this->getAccueilURL()."/addKit";
	}

	public function getAssociationKitURL(){
		return $this->getAccueilURL()."/associationKit";
	}

	public function getDeplacerKitURL(){
		return $this->getAccueilURL()."/deplacerKit";
	}

	public function getMoveKitURL(){
		return $this->getAccueilURL()."/moveKit";
	}

	public function getDeleteKitURL($idK){
		return $this->getAccueilURL()."/deleteKit/".$idK;
	}

	public function getDeleteProduitCKURL($idP, $idK){
    return $this->getAccueilURL()."/deleteProduitCK/".$idP."/".$idK;
  }
	////**************PRODUIT********************////////////////////////

  public function getAccueilProduitURL($idPrd){
    return $this->getAccueilURL()."/produits/".$idPrd;
  }

  public function getNewProduitURL(){
    return $this->getAccueilURL()."/newProduit";
  }

  public function getAccueilModificationProduitURL($id){
    return $this->getAccueilURL()."/modifyAccueilProduit/".$id;
  }

	public function getMiseAJourProduitURL($id){
		return $this->getAccueilURL()."/MiseAJourProduit/".$id;
	}

  public function getModifyProduitURL($id){
    return $this->getAccueilURL()."/modifyProduit/".$id;
  }

  public function getAddProduitURL(){
    return $this->getAccueilURL()."/addProduit";
  }

  public function getDeleteProduitURL($idP){
    return $this->getAccueilURL()."/deleteProduit/".$idP;
  }

	public function getDeplacerProduitURL(){
		return $this->getAccueilURL()."/deplacerProduit";
	}

	public function getMoveProduitURL(){
		return $this->getAccueilURL()."/moveProduit";
	}

	public function getCréationKitURL(){
		return $this->getAccueilURL()."/creationProduit";
	}


	//////**********STOCK TOTAL*********/////////

  public function getStockTotalURL($idP){
    return $this->getAccueilURL()."/stockTotal/".$idP;
  }


   ////////////////////Logement////////////////////////

  public function getLogementsURL($id){
    return $this->getAccueilURL()."/logements/".$id;
  }
  public function getPretFormulaireURL($idEtudiant, $idLog){
    return $this->getAccueilURL()."/pretFormulaire/".$idEtudiant."/".$idLog;
  }
  public function getSavePretURL($id){
    return $this->getAccueilURL()."/savePret/".$id;
  }
  public function getModifyPretURL($idPret, $idLog){
    return $this->getAccueilURL()."/modifyPret/".$idPret."/".$idLog;
  }
  public function getConfirmModificationPretURL($id, $idLog){
    return $this->getAccueilURL()."/confirmModificationPret/".$id."/".$idLog;
  }
  public function getDeletePretURL($pret, $idLog){
    return $this->getAccueilURL()."/deletePret/".$pret."/".$idLog;
  }

  public function getEtudiantFormulaireURL($idLog){
    return $this->getAccueilURL()."/etudiantFormulaire/".$idLog;
  }

  public function getSaveEtudiantURL($id){
    return $this->getAccueilURL()."/saveEtudiant/".$id;
  }

  public function getDeleteEtudiantURL($idEtu, $idLog){
    return $this->getAccueilURL()."/deleteEtudiant/".$idEtu."/".$idLog;
  }

	public function getReturnPretURL($idP, $idL){
		return $this->getAccueilURL()."/return/".$idP."/".$idL;
	}
  /////////////////////////Blanchisseries///////////
  public function getBlanchisseriesURL(){
    return $this->getAccueilURL()."/blanchisseries";
  }

	public function getFormulaireDepartBlancheURL(){
		return $this->getAccueilURL()."/formulaireDepart";
	}

	public function getSaveDepartBlancheURL(){
		return $this->getAccueilURL()."/saveDepart";
	}

	public function getModifyBlanchisURL($idB){
		return $this->getAccueilURL()."/modifyBlanchis/".$idB;
	}
	public function getDeleteBlanchisURL($idB){
		return $this->getAccueilURL()."/deleteBlanchis/".$idB;
	}
	public function getConfirmModificationBlancheURL($idB){
		return $this->getAccueilURL()."/confirmModificationBlanche/".$idB;
	}
	public function getRetourBlancheURL($idB){
		return $this->getAccueilURL()."/retourBlanche/".$idB;
	}


///////////redurection feedback////////
  public function PostRedirect($url,$feedback){
        $_SESSION['feedback'] = $feedback;
        header("Location: ".htmlspecialchars_decode($url), true, 303);
    }
}
