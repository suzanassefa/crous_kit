<!DOCTYPE HTML>
<html lang="fr">
  <head>
    <title> <?php //echo $this->header; ?></title>
    <meta charset="utf-8"/>
    <link rel="stylesheet" href="<?php  echo $this->router->getStyleURL();?>" />
    <script src="<?php  echo $this->router->getJsURL();?>"></script>
  </head>

  <body>

    <header id="header">
      <img id='img-logo-delete' src='https://dev-21707895.users.info.unicaen.fr/stage/skin/crousLogo.jpg' alt='crousLogo'>
      <div class = "inner">
          <nav id="nav">
            <?php echo $this->menu;?>
          </nav>
      </div>
    </header>

    <section id= "section">

      <div class="inner">
        <div id="content1">
          <?php echo  $this->content1;?>
        </div>
        <div id="content2">
          <h2><?php echo $this->title; ?></h2>
          <?php echo  $this->content2;?>
        </div>
      </div>
    </section>
  </body>
</html>
