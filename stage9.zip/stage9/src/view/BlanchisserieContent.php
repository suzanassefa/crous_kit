<?php
$this->content2 .="  <div class='section'><table>";
$this->content2 .="<caption><div id='captionMois'>".$month."</div></caption>
      <tr>
        <th>Produit</th>
        <th>Date de Depart</th>
        <th>Quantite de Depart</th>
        <th>Date de Retour</th>
        <th>Qauntite de Retour</th>
        <th>Lieu de Retour</th>
        <th>Observation</th>
      </tr>";
foreach($blanchis as $b){


    $this->content2 .="<tr>";
    foreach($produit as $p){
      if($b['produit']== $p['idProduit']){
        $this->content2 .=" <td>".$p['nomProduit']."-".$p['nbPers']."pers</td>";
      }
    }

    $phpdateDepart = strtotime( $b['dateDepart'] );
    $mysqldateDepart = date( 'd-m-y', $phpdateDepart );
    $this->content2 .=" <td>".$mysqldateDepart."</td>
    <td>".$b['quantiteDepart']."</td>";

    $phpdateRetour = strtotime( $b['dateRetour'] );
    $mysqldateRetour = date( 'd-m-y', $phpdateRetour );

    if($b['dateRetour']=="0000-00-00"){
      $b['dateRetour'] = NULL;
      $this->content2 .=" <td>".$b['dateRetour']."</td>";
      $this->content2 .="<td> </td>";
    }else{
      $this->content2 .=" <td>".$mysqldateRetour."</td>";
      $this->content2 .="<td>".$b['quantiteRetour']."</td>";

    }

    $this->content2 .="<td>".$b['lieu']."</td>
    <td>".$b['observation']."</td>
    <td><a href = '".$this->router->getModifyBlanchisURL($b['idBlanchisserie'])."'><img id='img-logo-delete' src='https://dev-21707895.users.info.unicaen.fr/stage/skin/editLogo.png' alt='editLogo'></a></td>
    <td><a href = '".$this->router->getDeleteBlanchisURL($b['idBlanchisserie'])."' onclick='return confirm(\"Vous êtes sure de vouloir le suprimer le produit ".$b['produit']." ?\")'><img id='img-logo-delete' src='https://dev-21707895.users.info.unicaen.fr/stage/skin/deleteLogo.jpg' alt='deleteLogo'></</a></td>
</tr>";

}
        $this->content2.= "</table>";
