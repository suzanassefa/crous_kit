<?php
///crée un nouveau produit
$this->title = $produit['nomProduit']."-".$produit['nbPers'];

// Modifié le produit selectionner
$this->content2 .= "<div class='content1createKit' > <h3> Modifier ".$produit['nomProduit']."-".$produit['nbPers']." </h3><form method = 'POST' action='".$this->router->getModifyProduitURL($produit['idProduit'])."'>
<label for='nomProduit'>Produit  </label>
<input type ='text' id='nomProduit' name='nomProduit' value='".$produit['nomProduit']."'><br/><br/>

<label for='nbPers'>nombre de personne  </label>
<input type ='text' id='nbPers' name='nbPers' value='".$produit['nbPers']."'><br/><br/>

<label for='type'>Type  </label>
<input type ='text' id='type' name='type' value='".$produit['type']."'><br/><br/>

<label for='description'>description : </label>
<input type ='text' id='description' name='description' value='".$produit['descriptionP']."'><br/><br/>


  <label for='lcr'>Quantité au LCR  </label>
  <input type ='lcr' id='lcr' name='lcr' value=".$produit['LCR']."><br/><br/>

  <label for='loge'>Quantité au LOGE  </label>
  <input type ='text' id='loge' name='loge' value=".$produit['LOGE']."><br/><br/>

  <label for='cave'>Quantité dans la Cave  </label>
  <input type ='text' id='cave' name='cave' value=".$produit['Cave']."><br/><br/>

  <label for='autre'>Autre lieu de stockage  </label>
  <input type ='text' id='autre' name='autre' value=".$produit['Autre']."><br/><br/>

  <label for='stockTotal'>Stock Total </label>
  <input type ='text' id='stockTotal' name='stockTotal' value=".$produit['StockTotal']."><br/><br/>

  <input type='submit'  onclick='return confirm(\"Vous êtes sure de vouloir le modifier cette kit ?\")' value='Modifier ce Produit'>
</form><br/><br/>
<a href='".$this->router->getDeleteProduitURL($produit['idProduit'])."' class='abutton' onclick='return confirm(\"Vous êtes sure de vouloir suprimer ".$produit['nomProduit']." ?\")'>SUPRIMER</a>
</div>";
