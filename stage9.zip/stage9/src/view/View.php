<?php
require_once("Router.php");

class View{
  public $router;
  public $title ;
  public $content1;
  public  $content2;
  public $feedback;

  public function __construct(Router $router, $feedback){
    $this->router = $router;
    $this->feedback = $feedback;
    $this->title = "";
    $this->content1 = "";
    $this->content2 = "";
    $this->menu = "";
  }

  public function render(){
    include_once("index.php");
  }



  //***********************home page******************************//

  public function makeLoginFormPage(){
    $this->title = "Page de connection";
    $this->content2 = "<div class='content1createKit' ><h2>Connection</h2><br/>";
    $this->content2 .="	<form action ='".$this->router->getConnectionReussiURL()."' method= 'POST'><br/><br/>";
    $this->content2 .= "<label>Nom : <input type ='text' name='username' required/></label><br/><br/>";
    $this->content2 .= "<label>Mot de passe : <input type ='password' name='password' required/></label><br/><br/>";
    $this->content2 .= "<button type='submit' name= 'login'  >Se connecter</button><br/>";
    $this->content2 .= "</form> <br/></div>";

  }

////////Redirection
  public function makeDebugPage($variable) {
    $this->title = "ERROR PAGE";
    $this->content1 = "<pre>".htmlspecialchars(var_export($variable, true)).'</pre>';
  }
  
  public function displayConnectionSucess(){
  $this->router->PostRedirect($this->router->getAccueilURL(), "Connection réussi");
  }

  public function dispalayConnectionFailure(){
    $this->router->PostRedirect($this->router->getAccueilURL(), "L'utilisateur ou le mots de passe n'est correct");
  }
}
