<?php
$this->content2 .= "<br/><br/><a href='".$this->router->getEtudiantFormulaireURL($idLog)."' class='abutton'> Ajouter un Etudiant</a> ";

foreach ($etudiants as $etu) {
  $this->content2 .="  <div class='section'><table>";
      $phpdateDP = strtotime( $etu['dateDepartPrevu']);
      $mysqldateDP = date( 'd-m-y', $phpdateDP );

        $this->content2 .=" <caption><div id='captionNom'>".$etu['nom']." ".$etu['prenom']."</div><div id='captionDate'> Date de départ Prévu : ".$mysqldateDP."</div></caption>
          <tr>
            <th>Nom du kit</th>
            <th>Date de prêt</th>
            <th>Lieu</th>
            <th>Mantant facturé</th>
            <th>Payeur</th>
            <th>Payement fait</th>
            <th>Observation</th>
            <th>Date de Retour</th>
            <th>Etat</th>
            <th></th>
            <th></th>
          </tr>";

          foreach ($prets as $p) {
            if($p['etudiant'] == $etu['idEtudiant']){
              $this->content2.="<tr>";
              foreach($kits as $k){
                if($p['kit']==$k['idKit']){
                  $nomKit = $k['nomKit'];
                  $nbPers = $k['nbPers'];
                }
              }
              $this->content2.="<td>".$nomKit."-".$nbPers."</td>";

              $phpdateP = strtotime( $p['datePret'] );
              $mysqldateP = date( 'd-m-y', $phpdateP );
              $this->content2.=" <td>".$mysqldateP."</td>

              <td>".$p['lieu']."</td>
                <td>".$p['montantFacturer']."</td>
                <td>".$p['Payeur']."</td>
                <td>".$p['estPayer']."</td>";

                if($isReturned[$p['idPret']]== '1'){
                  foreach($retour as $r){
                    if($p['idPret']==$r['pret']){
                      $this->content2.=" <td>".$p['observation']." ".$r['observation']."</td>";

                      $phpdateR = strtotime( $r['dateRetourPret'] );
                      $mysqldateR = date( 'd-m-y', $phpdateR );
                    $this->content2.=" <td> ".$mysqldateR."</td>

                      <td>".$r["etat"]." </td>";
                    }
                  }
                }else{
                    $this->content2.=" <td>".$p['observation']."</td>
                    <td> </td>
                    <td> </td>";
                }


              $this->content2.="  <td><a href = '".$this->router->getModifyPretURL($p['idPret'], $idLog)."'><img id='img-logo-delete' src='https://dev-21707895.users.info.unicaen.fr/stage/skin/editLogo.png' alt='editLogo'></a></td>
                <td><a href = '".$this->router->getDeletePretURL($p['idPret'], $idLog)."' onclick='return confirm(\"Vous êtes sure de vouloir le suprimer le ".$nomKit."-".$nbPers." de ".$etu['nom']." ".$etu['prenom']."?\")'><img id='img-logo-delete' src='https://dev-21707895.users.info.unicaen.fr/stage/skin/deleteLogo.jpg' alt='deleteLogo'></</a></td>
              </tr>";
          }
        }

        $this->content2.= "</table>";
        $this->content2 .= "<a href='".$this->router->getPretFormulaireURL($etu['idEtudiant'], $idLog)."' class='abutton'> Ajouter un Kit</a> ";
        $this->content2 .= "<a href='".$this->router->getDeleteEtudiantURL($etu['idEtudiant'], $idLog)."' class='abutton' onclick='return confirm(\"Vous êtes sure de vouloir le suprimer ".$etu['nom']." ".$etu['prenom']." ainsi que ces données ?\")'>Suprimer l'étudiant et ses données</a></div>";

}
