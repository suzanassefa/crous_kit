<?php

$this->content2 .= "<div class='content1createKit' > <h3> Modifier ".$kit['nomKit']." </h3><form method = 'POST' action='".$this->router->getModifyKitURL($kit['idKit'])."'>
  <label for='nomKit'>Kit : </label>
  <input type ='text' id='nomKit' name='nomKit' value='".$kit['nomKit']."'><br/><br/>

  <label for='nbPers'>nombre de personne  </label>
  <input type ='text' id='nbPers' name='nbPers' value=".$kit['nbPers']."><br/><br/>

  <label for='description'> Description  </label>
  <input type ='text' id='description' name='description' value='".$kit['descriptionK']."'><br/><br/>

  <label for='tarif-semaine'> Tarif/semaine  </label>
  <input type ='text' id='tarif-semaine' name='tarif-semaine' value='".$kit['tarif-semaine']."'><br/><br/>

  <label for='tarif-annuel'>Tarif annuel  </label>
  <input type ='text' id='tarif-annuel' name='tarif-annuel' value='".$kit['tarif-annuel']."'><br/><br/>

  <label for='lcr'>Quantité au LCR  </label>
  <input type ='lcr' id='lcr' name='lcr' value=".$kit['LCR']."><br/><br/>

  <label for='loge'>Quantité au LOGE  </label>
  <input type ='text' id='loge' name='loge' value=".$kit['LOGE']."><br/><br/>

  <label for='cave'>Quantité dans la Cave  </label>
  <input type ='text' id='cave' name='cave' value=".$kit['Cave']."><br/><br/>

  <label for='autre'>Autre lieu de stockage  </label>
  <input type ='text' id='autre' name='autre' value=".$kit['Autre']."><br/><br/>

  <label for='stockTotal'>Stock Total  </label>
  <input type ='text' id='stockTotal' name='stockTotal' value=".$kit['StockTotal']."><br/><br/>

  <input type='submit'  onclick='return confirm(\"Vous êtes sure de vouloir le modifier cette kit ?\")' value='Modifier un Kit'>
</form>
<br/><br/>
<a href='".$this->router->getDeleteKitURL($kit['idKit'])."' class='abutton' onclick='return confirm(\"Vous êtes sure de vouloir suprimer ".$kit['nomKit']." ?\")'>SUPRIMER</a>
</div>";


$this->content1 .="<div class='content1createKit' >";
$this->content1 .="<h2>Les produits de ".$kit['nomKit']." </h2><ul>";
foreach ($createKits as $ck) {
  if($kit['idKit']==$ck['kit']){
    foreach ($produits as $prd) {
      if($prd['idProduit']==$ck['produit']){
        $this->content1 .="<li>".$ck['quantite']." ".$prd['nomProduit']."-".$prd['nbPers']."<a href='".$this->router->getDeleteProduitCKURL($prd['idProduit'], $kit['idKit'])."' onclick='return confirm(\"Vous êtes sure de vouloir suprimer ".$prd['nomProduit']." ?\")'><img id='img-logo-delete' src='https://dev-21707895.users.info.unicaen.fr/stage/skin/deleteLogo.png' alt='deleteLogo'></a></li>";
      }
    }
  }
}
$this->content1 .="</ul>
<h3>Ajouter un produit </h3>
<form method = 'POST' action='".$this->router->getAssociationKitURL()."'>
<input type='hidden' id='kit' name='kit' value='".$kit['idKit']."'>

  <select id='produit' name='produit' require>";
  foreach ($produits as $prd){
    $this->content1 .="<option value='".$prd['idProduit']."'>".$prd['nomProduit']."  ".$prd['nbPers']."</option>";
  }
  $this->content1 .="</select><br/><br/>

  <label for='quantite'>Quantité  </label>
  <select id='quantite' name='quantite' require>
    <option >1</option>
    <option >2</option>
    <option >3</option>
  </select><br/><br/>
  <input type='submit'  onclick='return confirm(\"Vous êtes sure de vouloir le ajouter ce Produit?\")' value='Ajouter un Produit'>
</form></div>";

 ?>
