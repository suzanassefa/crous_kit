<?php
$this->content2 .=   "<form method = 'POST' action='".$this->router->getSavePretURL($logement['idLogements'])."'>
<input type='hidden' id='idEtudiant' name='idEtudiant' value='".$etudiant['idEtudiant']."'>

<h3>".$logement['logement']." ".$etudiant['nom']." ".$etudiant['prenom']."</h3>


  <label for='dateP'>Date de prêt</label>
  <input type='date' id='dateP' name='dateP' value= new DateTime('NOW')
       min='2020-01-01' max='2030-12-31' required>

</br></br>


  <label for='kit'>Kit</label>
  <select id='kit' name='kit' require>";
  foreach ($kits as $k){
    $this->content2 .="<option value='".$k['idKit']."'>".$k['nomKit']."  ".$k['nbPers']."</option>";
  }
  $this->content2 .="</select>

  </br></br>

  <label for='lieu'>Lieu du pret </label>
  <select id='lieu' name='lieu' required>
    <option value='LCR'>LCR</option>
    <option value='LOGE'>LOGE</option>
    <option value='Cave'>Cave</option>
    <option value='Autre'>Autre</option>
  </select>

  </br></br>

  <label for='payeur'>Payeur</label>
  <select id='payeur' name='payeur' required>
    <option value='etudiant'>etudiant </option>
    <option value='tiers-groupe'>tiers groupe</option>
  </select>

  </br></br>

  <label for='montant'>Montant à payer:</label>
  <input type = 'text' id='montant' name='montant' >

  </br></br>

  <label for='estPayer'>Le payement est effectuer? </label>
  <select  id='estPayer' name='estPayer' required>
    <option value='TRUE'> Oui</option>
    <option value='FALSE'>Non </option>
  </select>

   </br></br>

   <label for='observation'>Observation:</label>
   <input type ='text' id='observation' name='observation'>

   </br></br>

  <input type='submit' value='Submit'>
</form>";


//"<label>Nom :<input type='text' name = 'nom' value = ".$paysLigne['nom']." required/></label>\n";
