<?php
require_once("Router.php");

class UserView extends View{
  public $comptes;
  public $menu;

  public function __construct(Router $router, $comptes, $feedback){
    parent::__construct($router,$feedback);
    $this->comptes=$comptes;
    $this->menu = $this->getMenu();
  }

  public function render(){
    include_once("index.php");
  }

  public function getMenu(){
    return "<a href='".$this->router->getAccueilProduitURL(1)."'>Produit</a>
    <a href='".$this->router->getAccueilKitURL(1)."'>Kit</a>
    <a href='".$this->router->getLogementsURL(3)."'>Prets</a>
    <a href='".$this->router->getBlanchisseriesURL()."'>Blanchisseries</a>
    <a href='".$this->router->getDeconnectionURL()."' onclick='return confirm(\"Voulez vous être déconnecter ?\")' >Deconnection</a>";
  }

  //***********************home page******************************//

  public function HomePageListKit($produits, $kits){
    $this->content1 = "<ul id='menu-accordeon'>
      <li><a href='#'>Kits</a>
      <ul>";
    foreach ($kits as $ligne){
      //var_dump($ligne);
      $this->content1 .= "<li><a href='".$this->router->getAccueilKitURL($ligne['idKit'])."'>".$ligne['nomKit']." ".$ligne['nbPers']."pers</a></li>";
    }
    $this->content1 .= "</ul>
      </li>
      </ul><br/><br/>";

  }
  public function HomePageListProduit($produits, $kits){
    $this->content1 = "<ul id='menu-accordeon'>
       <li > <a href='#'>Produits</a>
       <ul>";
    foreach ($produits as $ligne){
      $this->content1 .= "<li><a href='".$this->router->getAccueilProduitURL($ligne['idProduit'])."' >".$ligne['nomProduit']." ".$ligne['nbPers']."pers</a></li>";
    }
    $this->content1 .= "</ul>
      </li>
      </ul><br/><br/>";


  }

  public function HomePageContentKit($createKits, $kit, $produits, $stockL, $countStockPret){
    include_once('HomePageContentKit.php');

  }

  public function HomePageContentProduit($produit, $stockL, $countBlanchisserie){
    include_once('HomePageContentProduit.php');
  }

  public function deplacerKit($kits){
    $this->content2 .= "<div class='content1createKit' ><h3>Déplacer les Kits</h3><form method = 'POST' action='".$this->router->getMoveKitURL()."'>

    <label for='kit'>Kit</label>
    <select id='kit' name='kit' require>";
    foreach ($kits as $k){
      $this->content2 .="<option value='".$k['idKit']."'>".$k['nomKit']."  ".$k['nbPers']."</option>";
    }
    $this->content2 .="</select><br/><br/>

    <label for='stockOrigine'>Déplacer de : </label>
    <select id='stockOrigine' name='stockOrigine' required>
      <option value= 'LCR'>LCR</option>
      <option value= 'LOGE'>LOGE</option>
      <option value='Cave'>Cave</option>
      <option value='Autre'>Autre</option>
    </select><br/><br/>

    <label for='stockFinale'>Vers : </label>
    <select id='stockFinale' name='stockFinale' required>
      <option value= 'LCR'>LCR</option>
      <option value= 'LOGE'>LOGE</option>
      <option value='Cave'>Cave</option>
      <option value='Autre'>Autre</option>
    </select><br/><br/>


        <label for='quantite'>Quantité: </label>
        <input type ='text' id='quantite' name='quantite' required><br/><br/>

    <input type='submit'  onclick='return confirm(\"Déplacer ces Kits?\")' value='Déplacer'>
  </form></div><br/>";
  }

  public function deplacerProduit($produits){
    $this->content2 .= "<div class='content1createKit' ><h3>Déplacer les Produits</h3><form method = 'POST' action='".$this->router->getMoveProduitURL()."'>

    <label for='produit'>Kit</label>
    <select id='produit' name='produit' require>";
    foreach ($produits as $p){
      $this->content2 .="<option value='".$p['idProduit']."'>".$p['nomProduit']."  ".$p['nbPers']."</option>";
    }
    $this->content2 .="</select><br/><br/>

    <label for='stockOrigine'>Déplacer de : </label>
    <select id='stockOrigine' name='stockOrigine' require>
      <option value= 'LCR'>LCR</option>
      <option value= 'LOGE'>LOGE</option>
      <option value='Cave'>Cave</option>
      <option value='Autre'>Autre</option>
    </select><br/><br/>

    </select>
    <label for='stockFinale'>Vers : </label>
    <select id='stockFinale' name='stockFinale' require>
      <option value= 'LCR'>LCR</option>
      <option value= 'LOGE'>LOGE</option>
      <option value='Cave'>Cave</option>
      <option value='Autre'>Autre</option>
    </select><br/><br/>


        <label for='quantite'>Quantité: </label>
        <input type ='text' id='quantite' name='quantite'><br/><br/>

    <input type='submit'  onclick='return confirm(\"Déplacer ces Produits?\")' value='Dépalcer'>
  </form></div>";
  }

  public function formulaireCreationKit($kits){
    $this->content2 .= "<div class='content1createKit' ><h3> Création de Kit</h3><form method = 'POST' action='".$this->router->getCreationKitURL()."'>

      <label for='kit'>Kit</label>
      <select id='kit' name='kit' require>";
      foreach ($kits as $k){
        $this->content2 .="<option value='".$k['idKit']."'>".$k['nomKit']."  ".$k['nbPers']."</option>";
      }
      $this->content2 .="</select><br/><br/>

      <label for='stockOrigine'>Stock Origine des Produits </label>
      <select id='stockOrigine' name='stockOrigine' required>
        <option value='LCR'>LCR</option>
        <option value='LOGE'>LOGE</option>
        <option value='Cave'>Cave</option>
        <option value='Autre'>Autre</option>
      </select><br/><br/>

      <label for='stockFinale'>Stock Finale du Kit </label>
      <select id='stockFinale' name='stockFinale' required>
        <option value='LCR'>LCR</option>
        <option value='LOGE'>LOGE</option>
        <option value='Cave'>Cave</option>
        <option value='Autre'>Autre</option>
      </select><br/><br/>

      <label for='quantite'>Quantité: </label>
      <input type ='text' id='quantite' name='quantite'><br/><br/>

      <input type='submit' onclick='return confirm(\"Vous êtes sure de vouloir crée un ce Kit?\")' value='Crée un Kit'>
    </form>
    </div>";
  }


//***************************Logement*********************//
  public function LogementList($batiments, $logement){

    include_once("LogementList.php");
  }

  public function LogementContent($kits, $etudiants, $prets, $idLog, $retour, $isReturned){
    include_once("LogementContent.php");
  }

  public function pretFormualire($logement, $etudiant, $kits){
    include_once("FormulairePret.php");
  }
  public function pretModificationForm($pretsLigne, $logement, $etudiant, $kits){
    include_once("ModificationPret.php");
  }

  public function etudiantFormulaire($id){
    $this->content2 .=   "<form method = 'POST' action='".$this->router->getSaveEtudiantURL($id)."'>
    <label for='nom'>Nom:</label>
    <input type ='text' id='nom' name='nom'>
    </br></br>
    <label for='prenom'>Prenom:</label>
    <input type ='text' id='prenom' name='prenom'>
    </br></br>
    <label for='num-tel'>Numeros de Téléphone:</label>
    <input type ='text' id='num-tel' name='num-tel'>
    </br></br>
    <label for='dateDepartPrv'>Date de départ prévu </label>
    <input type='date' id='dateDepartPrv' name='dateDepartPrv' value= new DateTime('NOW')
         min='2020-01-01' max='2030-12-31' required>
         </br></br>

   <input type='submit' value='Enregistrer'>
   </form>";
  }


  //////////************BLanchiserrie**********************//////////
  public function blanchisserieContent($blanchis, $month, $produit) {
    include('BlanchisserieContent.php');
  }
  public function BlanchisserieMiseEnPage(){
    $this->content2 .= "<br/><br/><a href='".$this->router->getFormulaireDepartBlancheURL()."' class='abutton'> Mettre en départ Blanchisserie </a> ";
  }

  public function formulaireDepart($produit){
    $this->content2 .=   "<h3>Ajouter un départ au Blanchisserie</h3>
    <form method = 'POST' action='".$this->router->getSaveDepartBlancheURL()."'>
        <label for='produit'>Produit</label>
        <select id='produit' name='produit' require>";
          foreach ($produit as $p){
            $this->content2 .="<option value='".$p['idProduit']."'>".$p['nomProduit']."  ".$p['nbPers']."pers</option>";
          }
        $this->content2 .="</select>

        </br></br>

        <label for='dateDepart'>Date de départ </label>
        <input type='date' id='dateDepart' name='dateDepart' value= new DateTime('NOW')
             min='2020-01-01' max='2030-12-31' required>

        </br></br>


        <label for='quantiteDepart'>Quantité  </label>
        <input type = 'text' id='quantiteDepart' name='quantiteDepart' >

        </br></br>


         <label for='observation'>Observation:</label>
         <input type ='text' id='observation' name='observation'>

         </br></br>

        <input type='submit' value='Mettre en départ'>
    </form>";
  }

  public function modifyBlanchis($blanchisserie, $produit){
    $this->content2 .=   "<div class='content1createKit'> <h3>Ajouter un départ au Blanchisserie</h3>
    <form method = 'POST' action='".$this->router->getConfirmModificationBlancheURL($blanchisserie['idBlanchisserie'])."'>
        <label for='produit'>Produit</label>
        <select id='produit' name='produit' require>";
          foreach ($produit as $p){
            $this->content2 .="<option value='".$p['idProduit']."'>".$p['nomProduit']."  ".$p['nbPers']."pers</option>";
          }
        //  var_dump()
        $this->content2 .="</select>

        </br></br>

        <label for='dateDepart'>Date de départ </label>
        <input type='date' id='dateDepart' name='dateDepart' value='".$blanchisserie['dateDepart']."' required>

        </br></br>


        <label for='quantiteDepart'>Quantité  </label>
        <input type = 'text' id='quantiteDepart' name='quantiteDepart' value=".$blanchisserie['quantiteDepart'].">

        </br></br>

         <label for='observation'>Observation:</label>
         <input type ='text' id='observation' name='observation'value=".$blanchisserie['observation'].">

         </br></br>

        <input type='submit' value='Modifier'>
    </form></div>";

    $this->content1 .="<div class='content1createKit'>
      <h2>Mettre en retour</h2>
      <form method = 'POST' action='".$this->router->getRetourBlancheURL($blanchisserie['idBlanchisserie'])."'>

      <input type='hidden' id='produit' name='produit' value= '".$blanchisserie['produit']."' >
      <input type='hidden' id='dateDepart' name='dateDepart' value= '".$blanchisserie['dateDepart']."' >
      <input type='hidden' id='quantiteDepart' name='quantiteDepart' value= '".$blanchisserie['quantiteDepart']."' >

        </br></br>

        <label for='dateRetour'>Date de Retour </label>
        <input type='date' id='dateRetour' name='dateRetour' value= new DateTime('NOW')
             min='2020-01-01' max='2030-12-31' required>

        </br></br>


        <label for='quantiteRetour'>Quantité  </label>
        <input type = 'text' id='quantiteRetour' name='quantiteRetour'>

        </br></br>
        <label for='lieu'>Lieu du pret </label>
        <select id='lieu' name='lieu' required>
          <option value='LCR'>LCR</option>
          <option value='LOGE'>LOGE</option>
          <option value='Cave'>Cave</option>
          <option value='Autre'>Autre</option>
        </select>

        </br></br>

         <label for='observation'>Observation:</label>
         <input type ='text' id='observation' name='observation'value=".$blanchisserie['observation'].">

        </br></br>
        <input type='submit' value='Mettre en Retour'>

      </form>
    </div>";

  }

  ////////**************success failure********************////
  public function displaySuccess2Logement($id){
      $this->router->PostRedirect($this->router->getLogementsURL($id), "succes");
  }
  public function displaySuccess2Accueil(){
    $this->router->PostRedirect($this->router->getAccueilURL(), "sucess");
  }

  public function displaySuccess2AccueilModification(){
    $this->router->PostRedirect($this->router->getAccueilURL(), "sucess");
  }

  public function displayDeconnectionSucess(){
    $this->router->PostRedirect($this->router->getAccueilURL(), "<script>alert ('deconnection reussi') ;</script>");
  }

  public function dispalayDeconnectionFailure(){
    $this->router->PostRedirect($this->router->getAccueilURL(), "Vous n'êtes toujours pas déconnecter");
  }
  public function dispalayLoginExiste(){
      $this->router->PostRedirect($this->router->getAccueilURL(), "Ce login existe déja, choisissez d'autres");
  }

  public function displaySuccess2Blanchisserie(){
    $this->router->PostRedirect($this->router->getBlanchisseriesURL(), "Succes");

  }

  public function displaySuccess2CreationKit(){
    $this->router->PostRedirect($this->router->getCréationKitURL(), "Le kit a été créer avec succes");

  }




}
