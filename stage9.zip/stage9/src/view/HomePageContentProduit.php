<?php

//var_dump($countBlanchisserie);

$this->title = $produit['nomProduit']." ".$produit['nbPers'];
//include_once('AccueilDetail.php');
$this->content2 .="<table class='info' >
<tr>
  <th class='titre' > </th>
  <th class='titre' >Quantite</th>
  <th class='titre' >Date de mise a jour</th>
  <th class='titre' >observation</th>
</tr>
<tr class='infoStock'>
    <th>Stock LCR</th>
    <td>".$produit['LCR']."</td>
    <td></td>
    <td></td>
  </tr>
  <tr class='infoStock'>
    <th>Stock LOGE</th>
    <td>".$produit['LOGE']."</td>
    <td></td>
    <td></td>
  </tr>
  <tr class='infoStock'>
    <th>Stock Cave</th>
    <td>".$produit['Cave']."</td>
    <td></td>
    <td></td>
  </tr>
  <tr class='infoStock'>
    <th>Stock Autres</th>
    <td>".$produit['Autre']."</td>
    <td></td>
    <td></td>
  </tr>
  <tr class='infoStock'>
    <th>Stock Total</th>
    <td>".$produit['StockTotal']."</td>
    <td></td>
    <td></td>
  </tr>
  <tr class='infoPretBlanchisserie'>
    <th>Blanchisserie</th>
    <td>".$countBlanchisserie['count']."</td>
    <td></td>
    <td></td>
  </tr>";
  foreach ($stockL as $stock) {
    if($stock['type'] == "Destruction"){
          if($produit['idProduit'] == $stock['produit']){
            $this->content2 .="<tr class='infoStockLocal'>";
            $this->content2 .="<th>Destruction</th>";
            $phpdateSL = strtotime( $stock['dateSL'] );
            $mysqldateSL = date( 'd-m-y', $phpdateSL );

            $this->content2 .="<td>".$stock['quantite']."</td>
            <td>".$mysqldateSL."</td>
            <td>".$stock['observation']."</td>";
            $this->content2 .="</tr>";

          }
          //else{ $this->content2 .="<td></td><td></td><td></td>";}
    }
    if($stock['type'] == "Achat"){
            if($produit['idProduit'] == $stock['produit']){
              $this->content2 .="<tr class='infoStockLocal'>";
              $this->content2 .="<th>Achat</th>";

              $phpdateSL = strtotime( $stock['dateSL'] );
              $mysqldateSL = date( 'd-m-y', $phpdateSL );

              $this->content2 .="<td>".$stock['quantite']."</td>
              <td>".$mysqldateSL."</td>
              <td>".$stock['observation']."</td>";
              $this->content2 .="</tr>";

            }
            /**else{
              $this->content2 .="<tr class='infoStockLocal'>";
              $this->content2 .="<td></td><td></td><td></td><td></td>";
              $this->content2 .="</tr>";

            }**/
    }
    if($stock['type'] == "Inventaire"){
        if($produit['idProduit'] == $stock['produit']){
          $this->content2 .="<tr class='infoStockLocal'>";
          $this->content2.="  <th>Inventaire</th>";

          $phpdateSL = strtotime( $stock['dateSL'] );
          $mysqldateSL = date( 'd-m-y', $phpdateSL );

          $this->content2 .="<td>".$stock['quantite']."</td>
          <td>".$mysqldateSL."</td>
          <td>".$stock['observation']."</td>";
          $this->content2 .="</tr>";
        }
        //else{ $this->content2 .="<td></td><td></td><td></td>";}
    }
  }
$this->content2 .="</table>";
$this->content2 .= "<a href = '".$this->router->getDeplacerProduitURL()."' class='abutton'>Deplacer ce Produit</a>  ";
