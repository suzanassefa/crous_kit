<?php
$this->content2 .=   "<div class='content1createKit' ><h2> Mettre en retour </h2><form method = 'POST' action='".$this->router->getReturnPretURL($pretsLigne['idPret'], $logement['idLogements'])."'>
<input type='hidden' id='idEtudiant' name='idEtudiant' value='".$pretsLigne['etudiant']."'>
  <input type='hidden' id='kit' name='kit' value='".$pretsLigne['kit']."'>
  <input type='hidden' id='dateP' name='dateP' value= '".$pretsLigne['datePret']."' >
  <input type='hidden' id='lieu' name='lieu' value= '".$pretsLigne['lieu']."' >
  <input type='hidden' id='payeur' name='payeur' value= '".$pretsLigne['Payeur']."' >
  <input type = 'hidden' id='montant' name='montant' value= '".$pretsLigne['montantFacturer']."'>
  <input type = 'hidden' id='estPayer' name='estPayer' value= '".$pretsLigne['estPayer']."'>

  </br></br>


  <label for='dateP'>Date de retour</label>
  <input type='date' id='dateRetour' name='dateRetour' value= new DateTime('NOW')
       min='2020-01-01' max='2030-12-31' required='false'>
   </br></br>

   <label for='etat'>Etat</label>
   <select id='etat' name='etat' required='false'>
     <option value='blanchisseries'>blanchisserie</option>
     <option value='destruction'>destruction</option>
   </select>
   </br></br>

   <label for='observation'>Observation:</label>
   <input type ='text' id='observation' name='observation' >

   </br></br>

  <input type='submit' value='Submit'>
</form></div>";

////////////////////////////////////////////////////////////////////////

$this->content1 .=   "<h2> ".$logement['logement']." ".$etudiant['nom']." ".$etudiant['prenom']."</h2><div class='content1createKit' >
<h3>Modier les donnée de </h3>

<form method = 'POST' action='".$this->router->getConfirmModificationPretURL($pretsLigne['idPret'], $logement['idLogements'])."'>
  <input type='hidden' id='idEtudiant' name='idEtudiant' value='".$pretsLigne['etudiant']."'>

  <label for='dateP'>Date de prêt</label>
  <input type='date' id='dateP' name='dateP' value= '".$pretsLigne['datePret']."' required>

</br></br>

  <label for='kit'>Kit</label>
  <select id='kit' name='kit' require>";
  foreach ($kits as $k){
    $this->content1 .="<option value='".$k['idKit']."'>".$k['nomKit']."  ".$k['nbPers']."</option>";
  }
$this->content1 .=  "</select>
</br></br>

<label for='lieu'>Lieu du pret </label>
<select id='lieu' name='lieu' required>
  <option value='LCR'>LCR</option>
  <option value='LOGE'>LOGE</option>
  <option value='Cave'>Cave</option>
  <option value='Autre'>Autre</option>
</select>

</br></br>

  <label for='payeur'>Payeur</label>
  <select id='payeur' name='payeur' required>
    <option value='etudiant'>etudiant </option>
    <option value='tiers-groupe'>tiers groupe</option>
    <option value='gratuit'>gratuit</option>
  </select>
  </br></br>

  <label for='estPayer'>Montant à payer:</label>
  <input type = 'text' id='montant' name='montant' value= '".$pretsLigne['montantFacturer']."'>

  </br></br>

  <label for='estPayer'>Le payement est effectuer? </label>
  <select  id='estPayer' name='estPayer' required>
    <option value='TRUE'> Oui</option>
    <option value='FALSE'>Non </option>
  </select>

   </br></br>

   <label for='observation'>Observation:</label>
   <input type ='text' id='observation' name='observation' value= '".$pretsLigne['observation']."'>

   </br></br>

  <input type='submit' onclick='return confirm(\"Confirmer la modification ?\")' value='Modifier'>
</form></div>";
