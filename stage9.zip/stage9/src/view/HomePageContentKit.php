<?php
$this->title = $kit['nomKit'];
$this->content2 .="<table class='infoKit'>
<tr>
  <th class='titre' >Liste des produits de ce kit</th>
  <th class='titre' >Tarif par semaine</th>
  <th class='titre' >Tarif annuel </th>
  <th class='titre' >Description</th>
</tr>
<tr>
  <td><ul>";
    foreach ($createKits as $ck) {
      if($kit['idKit']==$ck['kit']){
        foreach ($produits as $prd) {
          if($prd['idProduit']==$ck['produit']){
            $this->content2 .="<li>".$ck['quantite']." ".$prd['nomProduit']."-".$prd['nbPers']."pers</li>";
          }
        }
      }
    }
  $this->content2 .="</ul></td>
  <td>".$kit['tarif-semaine']."</td>
  <td>".$kit['tarif-annuel']."</td>
  <td>".$kit['descriptionK']."</td>

</tr>
</table></br></br>";
$this->content2 .="<table class='info'>
<tr>
  <th class='titre' > </th>
  <th class='titre'>Quantite</th>
  <th class='titre'>Date de mise a jour</th>
  <th class='titre'>observations</th>
</tr>
  <tr class='infoStock'>
    <th>Stock LCR</th>
    <td>".$kit['LCR']."</td>
    <td></td>
    <td></td>
  </tr>
  <tr class='infoStock'>
    <th>Stock LOGE</th>
    <td>".$kit['LOGE']."</td>
    <td></td>
    <td></td>
  </tr>
  <tr class='infoStock'>
    <th>Stock Cave</th>
    <td>".$kit['Cave']."</td>
    <td></td>
    <td></td>
  </tr>
  <tr class='infoStock'>
    <th>Stock Autres</th>
    <td>".$kit['Autre']."</td>
    <td></td>
    <td></td>
  </tr>
  <tr class='infoStock'>
    <th>Stock Total</th>
    <td>".$kit['StockTotal']."</td>
    <td></td>
    <td></td>
  </tr>
  <tr class='infoPretBlanchisserie'>
    <th>Quantité de Prêt</th>
    <td>".$countStockPret['Count']."</td>
    <td></td>
    <td></td>
  </tr>";
  foreach ($stockL as $stock) {
    if($stock['type'] == "Inventaire"){
        if($kit['idKit'] == $stock['produit']){
          $this->content2 .="<tr class='infoStockLocal'>";
          $this->content2.="  <th>Inventaire</th>";

          $phpdateSL = strtotime( $stock['dateSL'] );
          $mysqldateSL = date( 'd/m/y', $phpdateSL );

          $this->content2 .="<td>".$stock['quantite']."</td>
          <td>".$mysqldateSL."</td><td></td>";
          $this->content2 .="</tr>";
        }
        //else{ $this->content2 .="<td></td><td></td><td></td>";}
      }
  }
$this->content2 .="</table>";
$this->content2 .="<a href = '".$this->router->getDeplacerKitURL()."' class='abutton'>Deplacer ce Kit</a> ";
$this->content2 .="<a href = '".$this->router->getCréationKitURL()."' class='abutton'>Création de Kit</a> ";
