<?php
require_once("Router.php");
require_once("view/UserView.php");

class AdminView extends UserView{
  public $router;
  public $title;
  public $content1;
  public $content2;
  public $menu;
  public $feedback;

  public function __construct($router, $comptes,$feedback){
      parent::__construct($router,$comptes,$feedback);
  }

  public function getMenu(){
    return "<a href='".$this->router->getAccueilProduitURL(1)."'>Produit</a>
    <a href='".$this->router->getAccueilKitURL(1)."'>Kit</a>
    <a href='".$this->router->getLogementsURL(3)."'>Prêt</a>
    <a href='".$this->router->getBlanchisseriesURL()."'>Blanchisseries</a>
    <a href='".$this->router->getInscriptionURL()."'>Inscription</a>
    <a href='".$this->router->getDeconnectionURL()."' onclick='return confirm(\"Voulez vous être déconnecter ?\")' >Deconnection</a>";
  }

  //***********************home page******************************//

  public function HomePageListKit($produits, $kits){
    $this->content1 = "<ul id='menu-accordeon'>
      <li><a href='#'>Kits</a>
      <ul>";
    foreach ($kits as $ligne){
      //var_dump($ligne);
      $this->content1 .= "<li><a href='".$this->router->getAccueilKitURL($ligne['idKit'])."'>".$ligne['nomKit']." ".$ligne['nbPers']."pers</a></li>";
    }
    $this->content1 .= "</ul>
      </li>
      </ul><br/><br/>
      <a href = '".$this->router->getNewKitURL()."' class='abutton'>Crée un type Kit</a>";

  }
  public function HomePageListProduit($produits, $kits){
    $this->content1 = "<ul id='menu-accordeon'>
       <li > <a href='#'>Produits</a>
       <ul>";
    foreach ($produits as $ligne){
      $this->content1 .= "<li><a href='".$this->router->getAccueilProduitURL($ligne['idProduit'])."' >".$ligne['nomProduit']." ".$ligne['nbPers']."pers</a></li>";
    }
    $this->content1 .= "</ul>
      </li>
      </ul><br/><br/>
      <a href = '".$this->router->getNewProduitURL()."' class='abutton'>Crée un Produit</a><br/><br/>";


  }

  public function HomePageContentKit($createKits, $kit, $produits, $stockL, $countStockPret){
    include_once('HomePageContentKit.php');
    $this->content2 .= "<a href = '".$this->router->getAccueilModificationKitURL($kit['idKit'])."' class='abutton' >Modifier ce type kit</a>";

  }

  public function HomePageContentProduit($produit, $stockL, $countBlanchisserie){
    include_once('HomePageContentProduit.php');
    $this->content2 .= "<a href = '".$this->router->getAccueilModificationProduitURL($produit['idProduit'])."' class='abutton'>Modifier ce Produit</a>  ";
    $this->content2 .= "<a href = '".$this->router->getMiseAJourProduitURL($produit['idProduit'])."' class='abutton'>Mise a jours des données</a>";

  }

  public function newProduit(){
    $this->content2 .= "<div class='content1createKit  creation' ><h3> Crée un nouveau Poduit </h3><form method = 'POST' action='".$this->router->getAddProduitURL()."'>
       <label for='nomProduit'>Produit  </label>
       <input type ='text' id='nomProduit' name='nomProduit'><br/><br/>

      <label for='nbPers'>nombre de personne  </label>
      <input type ='text' id='nbPers' name='nbPers'><br/><br/>

      <label for='type'>Type  </label>
      <input type ='text' id='type' name='type'><br/><br/>

      <label for='description'>descriptionP  </label>
      <input type ='text' id='description' name='description'><br/><br/>

      <label for='lcr'>Quantité au LCR  </label>
      <input type ='lcr' id='lcr' name='lcr'><br/><br/>

      <label for='loge'>Quantité au LOGE  </label>
      <input type ='text' id='loge' name='loge'><br/><br/>

      <label for='cave'>Quantité dans la Cave  </label>
      <input type ='text' id='cave' name='cave'><br/><br/>

      <label for='autre'>Autre lieu de stockage  </label>
      <input type ='text' id='autre' name='autre'><br/><br/>

      <label for='stockTotal'>Stock Total  </label>
      <input type ='text' id='stockTotal' name='stockTotal'><br/><br/>

      <input type='submit' onclick='return confirm(\"Vous êtes sure de vouloir le ajouter ce Produit ?\")' value='Ajouter un Produit'>
    </form>
    </div>";

  }

  public function newKit(){
    $this->content2 .= "<div class='content1createKit creation'><h3> Crée un nouveau Kit </h3><form method = 'POST' action='".$this->router->getAddKitURL()."'>
      <label for='nomKit'>Kit  </label>
      <input type ='text' id='nomKit' name='nomKit'><br/><br/>

      <label for='nbPers'>nombre de personne  </label>
      <input type ='text' id='nbPers' name='nbPers'><br/><br/>

      <label for='description'> Description  </label>
      <input type ='text' id='description' name='description'><br/><br/>

      <label for='tarif-semaine'> Tarif/semaine </label>
      <input type ='text' id='tarif-semaine' name='tarif-semaine'><br/><br/>

      <label for='tarif-annuel'>Tarif annuel  </label>
      <input type ='text' id='tarif-annuel' name='tarif-annuel'><br/><br/>

      <label for='lcr'>Quantité au LCR  </label>
      <input type ='lcr' id='lcr' name='lcr'><br/><br/>

      <label for='loge'>Quantité au LOGE  </label>
      <input type ='text' id='loge' name='loge'><br/><br/>

      <label for='cave'>Quantité dans la Cave  </label>
      <input type ='text' id='cave' name='cave'><br/><br/>

      <label for='autre'>Autre lieu de stockage  </label>
      <input type ='text' id='autre' name='autre'><br/><br/>

      <label for='stockTotal'>Stock Total  </label>
      <input type ='text' id='stockTotal' name='stockTotal'><br/><br/>

      <input type='submit'  onclick='return confirm(\"Vous êtes sure de vouloir le ajouter cette kit ?\")' value='Ajouter un Kit'>
    </form></div>";
  }

  public function modifyAccueilKit($createKits, $kits, $kit, $produits){
    include_once("ModifyAccueilKit.php");
   }

   public function modifyAccueilProduit($produit){
     include_once("ModifyAccueilProduit.php");
   }

   public function miseAJourProduit($produit){
     $this->content2 .= "<div class='content1createKit' ><h3> Mettre ajour les données de ".$produit['nomProduit']."-".$produit['nbPers']."</h3>
     <form method = 'POST' action='".$this->router->getStockTotalURL($produit['idProduit'])."'>

     <label for='type'>Type </label>
     <select id='type' name='type' required>
       <option value='Inventaire'>Inventaire</option>
       <option value='Achat'>Achat</option>
       <option value='Destruction'>Destruction</option>
     </select><br/><br>

     <label for='dateSL'>Date </label>
     <input type='date' id='dateSL' name='dateSL' value= new DateTime('NOW')
          min='2020-01-01' max='2030-12-31' required><br/><br/>

       <label for='quantite'>Quantité </label>
       <input type ='text' id='quantite' name='quantite'><br/><br/>

       <label for='stockFinale'> Lieu de Stockage (que pour les achats): </label>
       <select id='stockFinale' name='stockFinale' required>
         <option value= 'LCR'>LCR</option>
         <option value= 'LOGE'>LOGE</option>
         <option value='Cave'>Cave</option>
         <option value='Autre'>Autre</option>
       </select><br/><br/>

       <label for='Observation'>Observation  </label>
       <input type ='text' id='observation' name='observation'><br/><br/>

       <input type='submit' onclick='return confirm(\"Vous êtes sure de vouloir mettre ajour cette information ?\")' value='Mettre a jour'>
     </form>
     </div>";
   }


//***************************Logement*********************//

///*********************Inscription***************///////

  public function listEtInscription($account){
    $this->title = "Inscription";

    //$this->content2 .= "<h2>Inscription</h2><br/>";
    $this->content2 .= "<div class='content1createKit' ><form action ='".$this->router->getInscriptionSucessURL()."' method= 'POST'><br/>";
    $this->content2 .= "<label>Nom : <input type='text' name = 'nom' /></label><br/><br/>";
    $this->content2 .= "<label>Login : <input type='text' name='login' required/></label><br/><br/>";
    $this->content2 .= "<label>Mot de Passe : <input type='password' name='password1'required/></label><br/><br/>";
    $this->content2 .= "<label>Mot de Passe : <input type='password' name='password2'required/></label><br/><br/>";
    $this->content2 .= "<label>Statut :
    <select id='statut' name='statut' required>
      <option value='admin'>Administrateur</option>
      <option value='user'>Utilisateur</option>
    </select></label><br/><br/>";
    $this->content2 .= "<button type='submit' name='enregistrer'>Enregistrer</button><br/><br/>";
    $this->content2 .= "</form></div>";

    $this->content1="<h1>Listes des utilisateurs </h1><div class='content1createKit' >";
    foreach ($account as $ligne){
        $this->content1 =  $this->content1.$ligne['nom']." (".$ligne['statut'].")";
        $this->content1 .= "<a href = ".$this->router->getUserAskDeletionURL($ligne['id'])." onclick='return confirm(\"Vous êtes sure de vouloir le suprimer  ".$ligne['nom']."?\")'><img id='img-logo-delete' src='https://dev-21707895.users.info.unicaen.fr/stage/skin/deleteLogo.jpg' alt='deleteLogo'></a>";
        //$this->content1 .= "<a href = ".$this->router->getUserModificationURL($ligne['id']).">Transformer en Admin</a>\n";
        $this->content1 .= "<br/><br/>";
    }
    $this->content1 .= "</div>";

  }

////********************les redirection ************************////////
public function success2AccueilKit($idKit, $variable){
  $this->router->PostRedirect($this->router->getAccueilKitURL($idKit), $variable);

}

}
