<?php

require_once("model/AccountStorage.php");

class AccountStorage{
	protected $pdo;

	public function __construct($pdo){
		$this->pdo = $pdo;
	}


	public function checkAuth($login, $password){
		$requete = "SELECT * FROM user";
		$stmt = $this->pdo->query($requete);
		$tableau =$stmt->fetchAll();
		foreach($tableau as $ligne){
			if($ligne['login'] == $login){
				if(password_verify($password,$ligne['password'])){
				$_SESSION["user"] = array("id" => $ligne['id'], "nom" => $ligne['nom'], "login" => $ligne['login'], "password" => $ligne['password'], "statut" => $ligne['statut']);
				}
			}
		}
		return $_SESSION["user"];
	}

	public function cheakIfUserExistInDB(Account $a){
		$requete = "SELECT * FROM user WHERE login=:login";
		$stmt = $this->pdo->prepare($requete);
		$getlogin=$a->getLogin();
		$stmt->bindParam(":login",$getlogin);
		$stmt->execute();
		$ligne =$stmt->fetchAll();
		if(count($ligne)===0){
			return true;
		}
		return false;
	}

	public function addToDB(Account $a){
		$requete = 'INSERT INTO user (nom, login, password, statut) VALUES (?,?,?,?);';
		$stmt = $this->pdo->prepare($requete)->execute([$a->getNom(),$a->getLogin(),$a->getMotdePasse(),$a->getStatut()]);
	}

	public function read($id){
		$requete = "SELECT * FROM user WHERE id=:id";
		$stmt = $this->pdo->prepare($requete);
		$stmt->bindParam(":id" ,$id);
		$stmt->execute();
		$tableau =$stmt->fetch();
		return $tableau;
	}

	public function readAll(){
		$requete = 'SELECT * FROM user;';
		$stmt = $this->pdo->prepare($requete);
		$stmt->execute();
		$tableau =$stmt->fetchAll();
		return $tableau;
	}

	public function delete($id){
		$requete = 'DELETE FROM user  WHERE id=:id';
		$stmt = $this->pdo->prepare($requete);
		$id = intVal($id);
		$stmt->bindParam(":id" ,$id, PDO::PARAM_INT);
		var_dump($stmt);
	 $stmt->execute();
	 PRINT('HERE');
		return true;
	}

	public function update($id){
		$requete = "UPDATE user SET statut=? WHERE id = ?";
		$stmt = $this->pdo->prepare($requete);
		$stmt->execute(array('admin',$id));
		return $stmt;

	}


}
