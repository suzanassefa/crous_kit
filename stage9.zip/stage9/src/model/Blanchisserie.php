<?php
class Blanchisserie{
	private $produits;
  private $quantiteDepart;
  private $dateDepart;
	private $observation;
  private $quantiteRetour;
	private $dateRetour;
	private $lieu;


	public function __construct( $produits, $quantiteDepart, $dateDepart, $observation, $quantiteRetour= null, $dateRetour=null, $lieu = null){
		$this->lieu = $lieu;
    $this->produits = $produits;
    $this->quantiteDepart= $quantiteDepart;
    $this->dateDepart = $dateDepart;
    $this->quantiteRetour = $quantiteRetour;
    $this->dataRetour = $dateRetour;
    $this->observation = $observation;
	}



	public function getLieu() {
		return $this->lieu;
	}

	public function getProduit() {
		return $this->produits;
	}

	public function getQuantiteDepart(){
		return   $this->quantiteDepart;
	}

	public function getDateDepart(){
		return $this->dateDepart;
	}

	public function getQuantiteRetour(){
		return $this->quantiteRetour;
	}

  public function getDateRetour(){
    return $this->dataRetour;
  }

  public function getObeservation(){
    return $this->observation;
  }

}
