<?php
require_once('model/Produits.php');


class ProduitsBuilder{
  public $data;
  public $errors;
  // class qui permet de construire un objet d'instance Produit

  public function __contruct($data, $errors=null){
    $this->data = $data;
  }

  public function getData(){
    return $this->data;
  }

  public function getErrors(){
    return $this->errors;
  }

  //vérifie si les donnée entré par un formulaire sont dans le bon format
  public function isValid($data){
    if($_POST['nomProduit'] != ""
    and $_POST['nbPers'] != ""){
      return true;
    }else{
      $this->errors = "Les champs ne sont pas rempli avec des données correcte.";
      return false;
    }
  }


  //la fonction prend en paramètre les donnée qui sont vérifé et il crée  et renvoirl'instance et le renvoie avec en paramètre les donnée vérifié précédement
  // et l'identifiant du logement au l'étudiant habite. Il peut y avoir plusieur étudiant dans un logements
  // mais il s'agir des anciens habitant
  public function newProduit($data){
    return new Produits(htmlspecialchars($data['nomProduit']),
    intval($data['nbPers']),
    htmlspecialchars($data['type']),
    htmlspecialchars($data['description']),
    intval($data['lcr']),
    intval($data['loge']),
    intval($data['cave']),
    intval($data['autre']),
    intval($data['stockTotal']));
  }

}
