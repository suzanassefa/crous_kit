<?php

class Produits{
  protected $nom;
  //protected $lieuStokage;
  protected $quantite;
  protected $description;
  protected $type;
  protected $LCR;
  protected $LOGE;
  protected $Cave;
  protected $Autre;
  protected $total;

  public function __construct($nom, $quantite, $description, $type, $LCR, $LOGE, $Cave, $Autre, $total){
    $this->nom = $nom;
    $this->quantite = $quantite;
    $this->description = $description;
    $this->type = $type;
    $this->LCR = $LCR;
    $this->LOGE = $LOGE;
    $this->Cave = $Cave;
    $this->Autre = $Autre;
    $this->total = $total;
  }

  public function getNom(){
    return $this->nom;
  }

  public function getQuantite(){
    return $this->quantite;
  }

  public function getDescription(){
    return $this->description;
  }

  public function getType(){
    return $this->type;
  }

  public function getLCR(){
    return $this->LCR;
  }

  public function getLOGE(){
    return $this->LOGE;
  }

  public function getCave(){
    return $this->Cave;
  }

  public function getAutre(){
    return $this->Autre;
  }

  public function getTotal(){
    return $this->total;
  }
}
