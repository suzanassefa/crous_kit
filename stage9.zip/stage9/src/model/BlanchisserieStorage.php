<?php

// tous les requette en lien avec le tableau sql Etudiants sont guérer ici.
class BlanchisserieStorage{
  protected $pdo;

  public function __construct($pdo){
    $this->pdo = $pdo;
  }
// lecture du tableau en entier
  public function readAll(){
    $requete = 'SELECT * FROM Blanchisserie;';
    $stmt = $this->pdo->query($requete);
    $tableau =$stmt->fetchAll();
    return $tableau;
  }

  public function read($id){
    $requete = "SELECT * FROM Blanchisserie WHERE idBlanchisserie=:id;";
    $stmt = $this->pdo->prepare($requete);
    $data = array(':id' => $id);
    $stmt->execute($data);
    $ligne =$stmt->fetch();
    return $ligne;
  }

  public function addBlanchisserie($blanchisserie){
    $requete = "INSERT INTO Blanchisserie (produit, quantiteDepart, dateDepart, observation) VALUES (?,?,?,?,?)";
    $stmt = $this->pdo->prepare($requete);
    $data = array($blanchisserie->getProduit(), $blanchisserie->getQuantiteDepart(), $blanchisserie->getDateDepart(), $blanchisserie->getObeservation());
    $stmt->execute($data);
  }

  public function readMonth($m){
    $requete = "SELECT * FROM Blanchisserie WHERE MONTH (dateDepart)=:m;";
    $stmt = $this->pdo->prepare($requete);
    $stmt->bindParam(":m" ,$m);
    $stmt->execute();
    $tableau =$stmt->fetchAll();
    return $tableau;
  }

  public function delete($id){
    $requete = "DELETE FROM Blanchisserie WHERE idBlanchisserie=:id";
    $stmt = $this->pdo->prepare($requete);
    $stmt->bindParam(":id" ,$id, PDO::PARAM_INT);
    $stmt->execute();
    return true;
  }

  public function updateBlanch($blanchisserie, $id){
    $requete = "UPDATE Blanchisserie SET retourPret=?, produit=?, quantiteDepart=?, dateDepart=?, observation=? WHERE idBlanchisserie=?";
    $stmt = $this->pdo->prepare($requete);
    $data = array(3, $blanchisserie->getProduit(), $blanchisserie->getQuantiteDepart(), $blanchisserie->getDateDepart(), $blanchisserie->getObeservation(), $id);
    $stmt->execute($data);
    return true;
  }

  public function retourBlanch($blanchisserie, $id){
    $requete = "UPDATE Blanchisserie SET quantiteRetour=?, dateRetour=?, observation=?, lieu=? WHERE idBlanchisserie=?";
    $stmt = $this->pdo->prepare($requete);
    $data = array($blanchisserie->getQuantiteRetour(), $blanchisserie->getDateRetour(), $blanchisserie->getObeservation(), $blanchisserie->getLieu(), $id);
    $stmt->execute($data);
    return true;
  }

  public function countBlanchisserie(){
    $stmt = $this->pdo->prepare("SELECT COUNT(idBlanchisserie) as count FROM Blanchisserie WHERE quantiteRetour='0' AND dateRetour = '0000-00-00';");
    $stmt->execute();
    $tableau =$stmt->fetch();
    return $tableau;
  }

}
