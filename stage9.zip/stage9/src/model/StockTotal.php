<?php

class StockTotal{
  protected $produit;
  protected $type;
  protected $quantite;
  protected $observation;
  protected $date;
  protected $lieu;

  public function __construct($produit, $type, $date, $quantite, $lieu, $observation){
    $this->produit = $produit;
    $this->type = $type;
    $this->quantite = $quantite;
    $this->date = $date;
    $this->lieu = $lieu;
    $this->observation = $observation;
  }

  public function getType(){
    return $this->type;
  }

  public function getProduit(){
    return $this->produit;
  }

  public function getQuantite(){
    return $this->quantite;
  }

  public function getDateSL(){
    return $this->date;
  }

  public function getObservation(){
    return $this->observation;
  }

  public function getLieu(){
    return $this->lieu;
  }
}
