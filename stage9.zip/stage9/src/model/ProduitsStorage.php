<?php

class ProduitsStorage{
  protected $pdo;

  public function __construct($pdo){
    $this->pdo = $pdo;
  }

  public function readAll(){
    $requete = 'SELECT * FROM Produits;';
    $stmt = $this->pdo->query($requete);
    $tableau =$stmt->fetchAll();
    return $tableau;
  }

  public function read($id){
    $requete = "SELECT * FROM Produits WHERE idProduit=:id";
		$stmt = $this->pdo->prepare($requete);
		$stmt->bindValue(":id" ,$id);
		$stmt->execute();
		$tableau =$stmt->fetch();
		return $tableau;
  }


  public function addProduit($produit){
    $requete = "INSERT INTO Produits (nomProduit, nbPers, descriptionP, type, LCR, LOGE, Cave, Autre, StockTotal) VALUES (?,?,?,?,?,?,?,?,?);";
    $stmt = $this->pdo->prepare($requete);
    $d = array($produit->getNom(), $produit->getQuantite(), $produit->getDescription(), $produit->getType(), $produit->getLCR(), $produit->getLOGE(), $produit->getCave(), $produit->getAutre(), $produit->getTotal());
    $stmt->execute($d);
  }

  public function deleteProduit($id){
    $requete = 'DELETE FROM Produits WHERE idProduit=:id';
    $stmt = $this->pdo->prepare($requete);
    $stmt->bindParam(":id" ,$id, PDO::PARAM_INT);
    $stmt->execute();
    return true;
  }

  public function updateProduit(Produits $produit, $id){
    $requete = "UPDATE Produits SET nomProduit=?, nbPers=?, descriptionP=?, type=?, LCR=?, LOGE=?, Cave=?, Autre=?, StockTotal=? WHERE idProduit= ?";
    $stmt = $this->pdo->prepare($requete);
    $data = array($produit->getNom(), $produit->getQuantite(), $produit->getDescription(), $produit->getType(), $produit->getLCR(), $produit->getLOGE(), $produit->getCave(), $produit->getAutre(), $produit->getTotal(), $id);
    $stmt->execute($data);
    return true;

}

  public function calcul1a($lieu, $idProduit){
    $requete = "SELECT ".$lieu.", StockTotal FROM Produits WHERE idProduit =:idProduit";
    $stmt = $this->pdo->prepare($requete);
    $data = $stmt->bindParam(":idProduit" ,$idProduit, PDO::PARAM_INT);
    $stmt->execute();
    $tableau =$stmt->fetch();
    return $tableau;
  }

  public function calcul1b($lieu, $idProduit, $newLieu, $newStockTotal){
    $requete = "UPDATE Produits SET ".$lieu."=?, StockTotal= ? WHERE idProduit = ?";
    $stmt = $this->pdo->prepare($requete);
    $data = array($newLieu, $newStockTotal, $idProduit);
    $stmt->execute($data);
    return true;
  }

  public function moveProduit($data){
    $requete = "SELECT ".$data['stockOrigine'].", ".$data['stockFinale']." FROM Produits WHERE idProduit=:produit";
    $stmt = $this->pdo->prepare($requete);
    $stmt->bindParam(":produit" ,$data['produit'], PDO::PARAM_INT);
    $stmt->execute();
    $tableau =$stmt->fetch();

    $requete = "UPDATE Produits SET ".$data['stockOrigine']."=?, ".$data['stockFinale']."=? WHERE idProduit=?";
    $stmt = $this->pdo->prepare($requete);
    $d = array($tableau[$data['stockOrigine']]-$data['quantite'], $tableau[$data['stockFinale']]+$data['quantite'], $data['produit']);
    $stmt->execute($d);
    return true;
  }

  public function addToStock($produit, $quantite, $lieu){
    $tableau = $this->calcul1a($lieu, $produit);
    $newStockLieu = $tableau[$lieu] + $quantite;
    $newStockTotal =  $tableau['StockTotal'] + $quantite;
    return $this->calcul1b($lieu, $produit, $newStockLieu, $newStockTotal);
  }

}
