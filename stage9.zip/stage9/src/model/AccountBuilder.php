<?php
require_once("model/Account.php");


class AccountBuilder{
	public $data;
	public $errors;

	public function __construct($data, $errors=null){
		$this->data=$data;
		$this->errors = $errors;
	}

	public function getData(){
		return $this->data;
	}

	public function geterrors(){
		return $this->errors;
	}

	public function isUserConnected(){
		if($_SESSION['user'] == null){
			return false;
		}
		else{
			return true;
		}
	}
	public function isAdminConnected(){
		if($_SESSION['user']['status'] == 'admin'){
				return true;
		}
		else { return false ;}
	}

	public function getUserName(){
		if($_SESSION['user'] != null){
			return $_SESSION['user']['nom'];
		}
		else{
			echo " ";
		}
	}

	public function isValid(){
		if($this->data['username']!= ""
			and $this->data['password'] != ""){
			return true;
		}

		else{
			$this->errors ="Les champs ne sont pas rempli avec des données correcte.";
			return false;
		}
	}

	public function connecting($account){
		 #var_export($this->data);
		return $account->checkAuth(htmlspecialchars($this->data['username']),htmlspecialchars($this->data['password']));
	}


	public function deconnecting(){
		if($_SESSION['user'] != null){
			$_SESSION['user'] = null;
		}else{
			$this->errors ="Vous n'étiez pas connecter a la base.";
		}
		return $_SESSION['user'];
	}

	public function inscriptionValid(){
		if($this->data['nom']!= ""
			and $this->data['password1'] != ""
			and $this->data['password2'] != ""
      and $this->data['login'] != ""
			and $this->data['statut'] != ""){

			if($this->data['password1'] != $this->data['password2']){
				$this->errors ="les mots de passe ne sont pas identique";
				return false;
			}
			else{return true;}

		}else{
			$this->errors ="Les champs ne sont pas rempli avec des données correcte.";
			return false;
		}
	}

	public function inscrire(){
		$hash = password_hash(htmlspecialchars($this->data['password1']), PASSWORD_BCRYPT);

		//$account->addToDB(new Account(htmlspecialchars($this->data['nom']),htmlspecialchars($this->data['login']),$hash,'user'));

		$account = new Account(htmlspecialchars($this->data['nom']),htmlspecialchars($this->data['login']),$hash,htmlspecialchars($this->data['statut']));
		return $account;

	}


}
