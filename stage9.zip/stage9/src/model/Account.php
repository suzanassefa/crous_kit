<?php
class Account{
	private $nom;
	private $login;
	private $motdepasse;
	private $statut;

	public function __construct($nom, $login, $motdePasse, $statut){
		$this->nom = $nom;
		$this->login = $login;
		$this->motdePasse = $motdePasse;
		$this->statut = $statut;
	}



	public function getId() {
		return $this->nom;
	}

	public function getNom() {
		return $this->nom;
	}

	public function getLogin(){
		return $this->login;
	}

	public function getMotdePasse(){
		return $this->motdePasse;
	}

	public function getStatut(){
		return $this->statut;
	}

}
