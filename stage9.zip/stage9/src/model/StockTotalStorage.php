<?php

class StockTotalStorage{
  protected $pdo;

  public function __construct($pdo){
    $this->pdo = $pdo;
  }

  public function readAll(){
    $requete = 'SELECT * FROM StockTotal;';
    $stmt = $this->pdo->query($requete);
    $tableau =$stmt->fetchAll();
    return $tableau;
  }

  public function readStockLProduitType($stockL){
    $requete = "SELECT * FROM StockTotal where produit=? and type=?";
    $stmt = $this->pdo->prepare($requete);
    $d = array($stockL->getProduit(), $stockL->getType());
    $stmt->execute($d);
    $ligne = $stmt->fetch();
    return $ligne;
  }

  public function addStockL($stockL){
    $ligne = $this->readStockLProduitType($stockL);
    if($ligne === false){
      $requete = "INSERT INTO StockTotal (produit, type, quantite, dateSL, observation) VALUES (?,?,?,?,?);";
      $stmt = $this->pdo->prepare($requete);
      $d = array($stockL->getProduit(), $stockL->getType(), $stockL->getQuantite(), $stockL->getDateSL(), $stockL->getObservation());
      $stmt->execute($d);
    }else{
      $requete = "UPDATE  StockTotal SET quantite=?, dateSL=?, observation=? WHERE produit=? AND type=?";
      $stmt = $this->pdo->prepare($requete);
      if($stockL->getType()=== 'Inventaire'){
        $d = array($stockL->getQuantite(), $stockL->getDateSL(), $stockL->getObservation(), $stockL->getProduit(), $stockL->getType());
        $stmt->execute($d);
      }else{
        $valeurStockTotal= $ligne['quantite'] + $stockL->getQuantite();
        $d = array($valeurStockTotal, $stockL->getDateSL(), $stockL->getObservation(), $stockL->getProduit(), $stockL->getType());
        $stmt->execute($d);
      }
    }
  }



  public function readStockL($id){
    $requete = "SELECT * FROM StockTotal WHERE id=".$id.";";
    $stmt = $this->pdo->query($requete);
    $tableau =$stmt->fetch();
    return $tableau;
  }




}
