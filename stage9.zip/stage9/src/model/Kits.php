<?php
// class qui crée une instance Kit, les mutateur ne sont pas encore crée jugée pas nécessaire pour le moment

class Kits{
  protected $nom;
  protected $nbPersonne;
  protected $description;
  protected $tarifSemaine;
  protected $tarifAnnuel;
  protected $LCR;
  protected $LOGE;
  protected $Cave;
  protected $Autre;
  protected $total;

  public function __construct($nom, int $nbPersonne, float $tarifSemaine, float $tarifAnnuel, $description=NULL, $LCR, $LOGE, $Cave, $Autre, $total){
    $this->nom = $nom;
    $this->nbPersonne = $nbPersonne;
    $this->description = $description;
    $this->tarifSemaine = $tarifSemaine;
    $this->tarifAnnuel = $tarifAnnuel;
    $this->LCR = $LCR;
    $this->LOGE = $LOGE;
    $this->Cave = $Cave;
    $this->Autre = $Autre;
    $this->total = $total;
  }

  public function getNom(){
    return $this->nom;
  }

  public function getNbPersonne(){
    return $this->nbPersonne;
  }

  public function getDescription(){
    return $this->description;
  }

  public function getTarifAnnuel(){
    return $this->tarifAnnuel;
  }
  public function getTarifSemaine(){
    return $this->tarifSemaine;
  }

  public function getLCR(){
    return $this->LCR;
  }

  public function getLOGE(){
    return $this->LOGE;
  }

  public function getCave(){
    return $this->Cave;
  }

  public function getAutre(){
    return $this->Autre;
  }

  public function getTotal(){
    return $this->total;
  }
}
