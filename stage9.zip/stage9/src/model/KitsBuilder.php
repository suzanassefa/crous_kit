<?php
require_once('model/Kits.php');


class KitsBuilder{
  public $data;
  public $errors;
  // class qui permet de construire un objet d'instance Kit

  public function __contruct($data, $errors=null){
    $this->data = $data;
  }

  public function getData(){
    return $this->data;
  }

  public function getErrors(){
    return $this->errors;
  }

  //vérifie si les donnée entré par un formulaire sont dans le bon format
  public function isValid($data){

    if($_POST['nomKit'] != ""
    and $_POST['nbPers'] != ""){
      return true;
    }else{
      $this->errors = "Les champs ne sont pas rempli avec des données coorecte.";
      return false;
    }

    /**if($_POST['nomKit'] === "" and $_POST['nbPers'] === "" ){
      $this->errors = "Les kit et le nombre de personne ne sont pas donnée.";
      return false;
    }
     if(!is_float($_POST['tarif-annuel']) or !is_int($_POST['tarif-annuel']) or !is_float($_POST['tarif-semaine']) or !is_int($_POST['tarif-semaine'])){
      $this->errors = "Les champs ne sont pas rempli avec des données coorecte, donnez que la valeur du prix.";
      return false;
    }
    return true;**/
  }


  //la fonction prend en paramètre les donnée qui sont vérifé et il crée  et renvoirl'instance et le renvoie avec en paramètre les donnée vérifié précédement
  // et l'identifiant du logement au l'étudiant habite. Il peut y avoir plusieur étudiant dans un logements
  // mais il s'agir des anciens habitant
  public function newKit($data){
    return new Kits(htmlspecialchars($data['nomKit']),
    intval($data['nbPers']),
     floatval($data['tarif-semaine']),
      floatval($data['tarif-annuel']),
      htmlspecialchars($data['description']),
      intval($data['lcr']),
      intval($data['loge']),
      intval($data['cave']),
      intval($data['autre']),
      intval($data['stockTotal']));
  }

}
