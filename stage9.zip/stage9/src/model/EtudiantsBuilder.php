<?php
require_once('model/Etudiants.php');

// class qui permet de construire un objet d'instance Etudiant
class EtudiantsBuilder{
  public $data;
  public $errors;

  public function __contruct($data, $errors=null){
    $this->data = $data;
  }

  public function getData(){
    return $this->data;
  }

  public function getErrors(){
    return $this->errors;
  }

  //vérifie si les donnée entré par un formulaire sont dans le bon format

  public function isValid(){
    if($_POST['nom'] != ""
    and $_POST['prenom'] != ""
    and $_POST['num-tel'] != ""){
      return true;
    }else{
      $this->errors = "Les champs ne sont pas rempli avec des données coorecte.";
      return false;
    }

  }

//une fois vérifié il crée l'instance et le renvoie avec en paramètre les donnée vérifié précédement
// et l'identidiant du logement au l'étudiant habite. Il peut y avoir plusieur étudiant dans un logements
// mais il s'agir des anciens habitant
  public function newEtudiant($data, $id){
    return new Etudiants(htmlspecialchars($_POST['nom']),
     htmlspecialchars($_POST['prenom']),
     htmlspecialchars($_POST['num-tel']),
     $id,
     htmlspecialchars($_POST['dateDepartPrv']));
  }

}
