<?php


class Prets{
  protected $kit;
  protected $etudiant;
  protected $datePret;
  protected $estPayer;
  protected $payeur;
  protected $montantFacturer;
  protected $dateRetour;
  protected $etat;
  protected $observation;

  public function __construct($kit, $etudiant, $datePret, $estPayer, $payeur, $montantFacturer, $observation, $lieu, $dateRetour="", $etat=""){
    $this->kit = $kit;
    $this->etudiant = $etudiant;
    $this->datePret = $datePret;
    $this->estPayer = $estPayer;
    $this->payeur = $payeur;
    $this->montantFacturer = $montantFacturer;
    $this->observation=  $observation;
    $this->lieu=  $lieu;
    $this->dateRetour =$dateRetour;
    $this->etat =$etat;
  }

  public function getKit(){
    return $this->kit;
  }
  public function getEtudiant(){
    return $this->etudiant;
  }
  public function getDatePret(){
    return $this->datePret;
  }
  public function getEstPayer(){
    return $this->estPayer;
  }
  public function getPayeur(){
    return $this->payeur;
  }
  public function getMontantFacturer(){
    return $this->montantFacturer;
  }
  public function getObservation(){
    return $this->observation;
  }

  public function getDateRetour(){
    return $this->dateRetour;
  }
  public function getEtat(){
    return $this->etat;
  }
  public function getLieu(){
    return $this->lieu;
  }
}
