<?php

class KitsStorage{
  protected $pdo;

  public function __construct($pdo){
    $this->pdo = $pdo;
  }

  public function readAllKit(){
    $requete = 'SELECT * FROM Kits;';
    $stmt = $this->pdo->query($requete);
    $tableau =$stmt->fetchAll();
    return $tableau;
  }

  public function readKit($id){
    $requete = "SELECT * FROM Kits WHERE idKit=:id";
		$stmt = $this->pdo->prepare($requete);
		$stmt->bindValue(":id" ,$id);
		$stmt->execute();
		$tableau =$stmt->fetch();
		return $tableau;
  }

  public function readIdKit($kit){
    $requete = "SELECT idKit FROM Kits WHERE nomKit=:kit";
    $stmt = $this->pdo->prepare($requete);
    $stmt->bindValue(":kit" ,$kit);
    $stmt->execute();
    $tableau =$stmt->fetch();
    return $tableau;
  }

  public function addKit($kit){
    //$requete = "INSERT INTO Kits (nomKit, nbPers, descriptionK, tarifSemaine, tarifAnnuel, LCR, LOGE, Cave, Autre, StockTotal) VALUES (?,?,?,?,?,?,?,?,?,?);";
    $requete = "INSERT INTO Kits (nomKit, nbPers, descriptionK, LCR, LOGE, Cave, Autre, StockTotal) VALUES (?,?,?,?,?,?,?,?);";

    $stmt = $this->pdo->prepare($requete);
    $d = array($kit->getNom(), $kit->getNbPersonne(), $kit->getDescription(), $kit->getLCR(), $kit->getLOGE(), $kit->getCave(), $kit->getAutre(), $kit->getTotal());
//    $d = array($kit->getNom(), $kit->getNbPersonne(), $kit->getDescription(), $kit->getTarifSemaine(), $kit->getTarifAnnuel(), $kit->getLCR(), $kit->getLOGE(), $kit->getCave(), $kit->getAutre());
    $stmt->execute($d);
  }

  public function deleteKit($id){
    $requete = 'DELETE FROM CreateKit WHERE kit=:id';
    $stmt = $this->pdo->prepare($requete);
    $stmt->bindParam(":id" ,$id, PDO::PARAM_INT);
    $stmt->execute();

    $requete = 'DELETE FROM Kits WHERE idKit=:id';
    $stmt = $this->pdo->prepare($requete);
    $stmt->bindParam(":id" ,$id, PDO::PARAM_INT);
    $stmt->execute();
    return true;
  }

  public function updateKit(Kits $kit, $id){
    //  $requete = "UPDATE Kits SET nomKit=?, nbPers=?, descriptionK=?, tarifSemaine=?, tarifAnnuel=?, LCR=?, LOGE=?, Cave=?, Autre=? WHERE idKit= ?";
      $requete = "UPDATE Kits SET nomKit=?, nbPers=?, descriptionK=?, LCR=?, LOGE=?, Cave=?, Autre=?, StockTotal=? WHERE idKit= ?";
      $stmt = $this->pdo->prepare($requete);
      $data = array($kit->getNom(), $kit->getNbPersonne(), $kit->getDescription(), $kit->getLCR(), $kit->getLOGE(), $kit->getCave(), $kit->getAutre(),$kit->getTotal(), $id);
      //$data = array($kit->getNom(), $kit->getNbPersonne(), $kit->getDescription(), $kit->getTarifSemaine(), $kit->getTarifAnnuel(), $kit->getLCR(), $kit->getLOGE(), $kit->getCave(), $kit->getAutre(), $kit->getTotal(), s$id);
      $stmt->execute($data);
      return $stmt;
    }

  public function additionStockKit($data){
    $requete = "SELECT ".$data['stockFinale'].", StockTotal FROM Kits WHERE idKit =:idKit";
    $stmt = $this->pdo->prepare($requete);
    $d = $stmt->bindParam(":idKit" ,$data['kit'], PDO::PARAM_INT);
    $stmt->execute();
    $tableau =$stmt->fetch();

    $requete = "UPDATE Kits SET ".$data['stockFinale']."=?, StockTotal= ? WHERE idKit=?";
    $stmt = $this->pdo->prepare($requete);
    $d = array(($tableau[$data['stockFinale']] + $data['quantite']), ($tableau['StockTotal'] + $data['quantite']), $data['kit']);
    $stmt->execute($d);
    return true;
  }


  public function pretCalculStockKit($idKit, $lieu, $string){
    $requete = "SELECT StockTotal, ".$lieu." FROM Kits WHERE idKit =:idKit";
    $stmt = $this->pdo->prepare($requete);
    $stmt->bindParam(":idKit" ,$idKit, PDO::PARAM_INT);
    $stmt->execute();
    $tableau =$stmt->fetch();
    $requete = "UPDATE Kits SET  StockTotal= ?, ".$lieu."=? WHERE idKit=?";
    $stmt = $this->pdo->prepare($requete);
    if($string == "soustraction"){
      $d = array(($tableau['StockTotal'] - 1), ($tableau[$lieu] - 1), $idKit);
    }
    if($string == "addition"){
      $d = array(($tableau['StockTotal'] + 1), ($tableau[$lieu] + 1), $idKit);
    }
    $stmt->execute($d);
    return true;
  }

  public function moveKit($data){
    $requete = "SELECT ".$data['stockOrigine'].", ".$data['stockFinale']." FROM Kits WHERE idKit=:kit";
    $stmt = $this->pdo->prepare($requete);
    $stmt->bindParam(":kit" ,$data['kit'], PDO::PARAM_INT);
    $stmt->execute();
    $tableau =$stmt->fetch();

    $requete = "UPDATE Kits SET ".$data['stockOrigine']."=?, ".$data['stockFinale']."=? WHERE idKit=?";
    $stmt = $this->pdo->prepare($requete);
    $d = array($tableau[$data['stockOrigine']]-$data['quantite'], $tableau[$data['stockFinale']]+$data['quantite'], $data['kit']);
    $stmt->execute($d);
    return true;
  }


/////**********************CreateKit**************************/////////////
  public function readAllCreateKit(){
    $requete = "SELECT * FROM CreateKit;";
    $stmt = $this->pdo->query($requete);
    $tableau =$stmt->fetchAll();
    return $tableau;
  }

  public function readCreateKit($id){
    $requete = "SELECT * FROM CreateKit WHERE kit=:id;";
    $stmt = $this->pdo->prepare($requete);
		$stmt->bindValue(":id" ,$id);
		$stmt->execute();
		$tableau =$stmt->fetchAll();
		return $tableau;
  }

  public function createKit($data){
    $requete = 'INSERT INTO CreateKit (kit, produit, quantite) VALUES (?, ?, ?);';
    $stmt = $this->pdo->prepare($requete);
    $data = array($data['kit'], $data['produit'], $data['quantite']);
    $stmt->execute($data);
  }

  public function deleteCreateKit($idP, $idK){
    $requete = 'DELETE FROM CreateKit WHERE produit=:idP  and kit=:idK';
    $stmt = $this->pdo->prepare($requete);
    $stmt->bindParam(":idP" ,$idP, PDO::PARAM_INT);
    $stmt->bindValue(":idK" ,$idK);
    $stmt->execute();
    return true;
  }

  public function selectProduits($id){
    $requete = "SELECT produit, quantite FROM CreateKit WHERE kit=:id;";
    $stmt = $this->pdo->prepare($requete);
    $stmt->bindValue(":id" ,$id);
    $stmt->execute();
    $tableau =$stmt->fetchAll();
    return $tableau;
  }




}
