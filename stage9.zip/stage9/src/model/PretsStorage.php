<?php


class PretsStorage{
  protected $pdo;

  public function __construct($pdo){
    $this->pdo = $pdo;
  }
////lire tous les prets pour chaque étudiant habitant dans une logement reconu pas l'identifiant id
  public function readPretParEtudiant($id){
    $requete = "SELECT * FROM Prets as P NATURAL JOIN Etudiants as Et WHERE P.etudiant = Et.idEtudiant and logement =".$id.";";
    $stmt = $this->pdo->query($requete);
    $pret = $stmt->fetchAll();
    return $pret;
  }

  /// ajouter un pret dans la base de donnée du tableau Pret
  public function addPret(Prets $pret){
    //on prend tous les informations nécessaire dans le kit.
  //  $s = $this->pdo->prepare('SELECT idKit FROM Kits WHERE nomKit = :nomKit and nbPers = :nbPers');
    //$kit = $pret->getKit();
  //  $nbPers = $pret->getNbPers();
  //  $s->bindParam(':nomKit', $kit);
  //  $s->bindParam(':nbPers', $nbPers);
  // $s->execute();
  //  $idKit = $s->fetch();
    // on crée un Pret avec l'identifiant de l'étudiant et de l'étudiant.
    $requete = 'INSERT INTO Prets (kit, etudiant, datePret, Payeur, estPayer, montantFacturer, observation) VALUES (?, ?, ?, ?, ?, ?, ?);';
    $stmt = $this->pdo->prepare($requete);
    $data = array($pret->getKit(), $pret->getEtudiant(), $pret->getDatePret(), $pret->getPayeur(), $pret->getEstPayer(), $pret->getMontantFacturer(), $pret->getObservation());
    $stmt->execute($data);

    //$requete = 'INSERT INTO RetourPret (pret,)'
  }

  public function read($id){
    $stmt = $this->pdo->prepare("SELECT * FROM Prets where idPret = :id");
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $ligne = $stmt->fetch();
    return $ligne;
  }

  public function update(Prets $pret, $id){
    $requete = "UPDATE Prets SET kit=?, etudiant=?, datePret=?, Payeur=?, estPayer=?, montantFacturer=?, observation=?, lieu = ? WHERE idPret = ?";
    $stmt = $this->pdo->prepare($requete);
    $data = array($pret->getKit(), $pret->getEtudiant(), $pret->getDatePret(), $pret->getPayeur(), $pret->getEstPayer(), $pret->getMontantFacturer(),$pret->getObservation(), $pret->getLieu(), $id );
    $stmt->execute($data);
    return $stmt;
  }

  public function delete($id){
    $requete = "DELETE FROM Prets WHERE idPret=:id";
    $stmt = $this->pdo->prepare($requete);
    $stmt->bindParam(":id" ,$id, PDO::PARAM_INT);
    $stmt->execute();
    return true;
  }

  public function deleteParEtudiant($id){
    $requete = "DELETE FROM Prets WHERE etudiant=:id";
    $stmt = $this->pdo->prepare($requete);
    $stmt->bindParam(":id" ,$id, PDO::PARAM_INT);
    $stmt->execute();
    return true;
  }

  ///********************RETOUR********************/////////////////////


  public function readDistinctRetour(){
    $stmt= $this->pdo->prepare( "SELECT DISTINCT pret, dateRetourPret, etat, observation FROM RetourPret GROUP BY pret;");
    $stmt->execute();
    $tableau = $stmt->fetchAll();
    return $tableau;
  }

  public function readReturnPret($id){
    $stmt = $this->pdo->prepare("SELECT * FROM RetourPret where pret = :id");
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $ligne = $stmt->fetch();
    return $ligne;
  }

  public function addRetour($retour, $idP, $produits){
    foreach($produits as $p){
      $requete = 'INSERT INTO RetourPret (pret, produit, dateRetourPret, quantiteRetourPret, etat, observation) VALUES (?, ?, ?, ?, ?, ?);';
      $stmt = $this->pdo->prepare($requete);
      $data = array($idP, $p['produit'], $retour->getDateRetour(), $p['quantite'], $retour->getEtat(), $retour->getObservation());
      $stmt->execute($data);
    }
  }

  public function updateRetour($retour, $idP, $produits){
    foreach($produits as $p){
      $requete = 'UPDATE RetourPret SET dateRetourPret=?, etat=?, observation=? WHERE  pret =?, produit=?,  quantiteRetourPret=?;';
      $stmt = $this->pdo->prepare($requete);
      $data = array($retour->getDateRetour(), $retour->getEtat(), $retour->getObservation(), $idP, $p['produit'], $p['quantite']);
      $stmt->execute($data);
      print('here');
    }
  }

  public function readAll(){
    $stmt = $this->pdo->prepare("SELECT idPret FROM Prets");
    $stmt->execute();
    $tableau = $stmt->fetchAll();
    return $tableau;
  }


  public function isReturned(){
    $tableau = $this->readAll();
    $resultat = array();
    foreach($tableau as $t){
      $stmt = $this->pdo->prepare("SELECT EXISTS (SELECT *  FROM RetourPret, Prets where pret=".$t['idPret'].") as bool;");
      $stmt->execute();
      $bool = $stmt->fetch();
      $resultat[$t['idPret']]= $bool['bool'];
    }
    return $resultat;
  }

  public function countStockPret(){
    $stmt = $this->pdo->prepare("SELECT count(idPret) as Count FROM Prets WHERE idPret NOT IN (SELECT pret FROM RetourPret);");
    $stmt->execute();
    $result = $stmt->fetch();
    return $result;
  }

  public function dernierDate(){
    $stmt = $this->pdo->prepare("SELECT datePret FROM Prets ORDER BY idPret DESC LIMIT 1;");
    $stmt->execute();
    $result = $stmt->fetch();
  }
}
