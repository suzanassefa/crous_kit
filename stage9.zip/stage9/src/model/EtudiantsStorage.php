<?php

// tous les requette en lien avec le tableau sql Etudiants sont guérer ici.
class EtudiantsStorage{
  protected $pdo;

  public function __construct($pdo){
    $this->pdo = $pdo;
  }
// lecture du tableau en entier
  public function readAll(){
    $requete = 'SELECT * FROM Etudiants;';
    $stmt = $this->pdo->query($requete);
    $tableau =$stmt->fetchAll();
    return $tableau;
  }
//ùlecture des etudiants qui habite dans une logment dont l'identifiant et le $id qui est donnée en paramètre
  public function readEtudiantParLogement($id){
    $requete = "SELECT * FROM Etudiants WHERE logement=".$id.";";
    $stmt = $this->pdo->query($requete);
    $etudiants = $stmt->fetchAll();
    return $etudiants;
  }

//récupérer la ligne du tableau sql qui contien les information sur l'étudiant dont l'identifiant est donnée au paramètre $id
  public function readEtudiant($id){
    $requete = "SELECT * FROM Etudiants WHERE idEtudiant=:idEtudiant;";
    $stmt = $this->pdo->prepare($requete);
    $data = array(':idEtudiant' => $id);
    $stmt->execute($data);
    $ligne =$stmt->fetch();
    return $ligne;
  }

//ajouter un étudiant au tableau
  public function addEtudiant($etudiant){
    $requete = "INSERT INTO Etudiants (nom, prenom, numerosTel, logement, dateDepartPrevu) VALUES (?,?,?,?,?);";
    $stmt = $this->pdo->prepare($requete);
    $data = array($etudiant->getNom(), $etudiant->getPrenom(), $etudiant->getNumTel(), $etudiant->getLogement(), $etudiant->getDateDepart());
    $stmt->execute($data);
  }

//suprimer un étu$ du tableau
  public function delete($id){
    $requete = "DELETE FROM Etudiants WHERE idEtudiant=:id";
    $stmt = $this->pdo->prepare($requete);
    $stmt->bindParam(":id" ,$id, PDO::PARAM_INT);
    $stmt->execute();
    return true;
  }

}
