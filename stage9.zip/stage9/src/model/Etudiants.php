<?php

// class qui crée une instance Etudiant, les mutateur ne sont pas encore crée jugée pas nécessaire pour le moment
class Etudiants{
  protected $nom;
  protected $prenom;
  protected $num_tel;
  protected $logement;
  protected $dateDepart;


  public function __construct($nom, $prenom, $num_tel, int $logement, $dateDepart){
    $this->nom = $nom;
    $this->prenom = $prenom;
    $this->num_tel= $num_tel;
    $this->logement = $logement;
    $this->dateDepart = $dateDepart;
  }

  public function getNom(){
    return $this->nom;
  }
  public function getPrenom(){
    return $this->prenom;
  }
  public function getNumTel(){
    return $this->num_tel;
  }
  public function getLogement(){
    return $this->logement;
  }
  public function getDateDepart(){
    return $this->dateDepart;
  }

}
