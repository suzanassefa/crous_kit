<?php
require_once('model/Blanchisserie.php');


class BlanchisserieBuilder{
  public $data;
  public $errors;

  public function __contruct($data, $errors=null){
    $this->data = $data;
  }

  public function getData(){
    return $this->data;
  }

  public function getErrors(){
    return $this->errors;
  }

  //public function saveKit($n)

  public function isValid(){
    if($_POST['quantiteDepart'] != ""
    and $_POST['dateDepart'] != ""){
      return true;
    }else{
      $this->errors = "Les champs ne sont pas rempli avec des données coorecte.";
      return false;
    }

  }

  public function isValidRetour(){
    if($_POST['quantiteRetour'] != ""
    and $_POST['dateRetour'] != ""
    and $_POST['lieu'] != ""){
      return true;
    }else{
      $this->errors = "Les champs ne sont pas rempli avec des données coorecte.";
      return false;
    }

  }

  public function departBlanchisserie($data){
    return new Blanchisserie(htmlspecialchars($_POST['produit']),
      htmlspecialchars($_POST['quantiteDepart']),
      htmlspecialchars($_POST['dateDepart']),
      htmlspecialchars($_POST['observation']));
  }

  public function retourBlanchisserie($data){
    return new Blanchisserie(htmlspecialchars($_POST['produit']),
      htmlspecialchars($_POST['quantiteDepart']),
      htmlspecialchars($_POST['dateDepart']),
      htmlspecialchars($_POST['observation']),
      htmlspecialchars($_POST['quantiteRetour']),
      htmlspecialchars($_POST['dateRetour']),
      htmlspecialchars($_POST['lieu']));
  }
}
