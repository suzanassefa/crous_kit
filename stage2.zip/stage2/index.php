<?php
set_include_path("./src");


require_once("Router.php");
require_once("model/ProduitsStorage.php");
require_once("model/LogementsStorage.php");
/**try {
  $bd = new PDO("mysql:host=10.246.64.131;dbname=kiLinge;charset=utf8",devher,Hdev90!);
  $bd->setAttribute(PDO::ATTR ERRMODE, PDO::ERRMODE EXCEPTION).
}catch(PDOException $e){
  echo "probleme sur connection de la bd : ".$e->getMessage();
}**/
require_once("/users/21707895/private/mysql_config.php");
	try{
		$bd= new PDO("mysql:host=".MYSQL_HOST.";dbname=".MYSQL_DB.";charset=utf8",MYSQL_USER, MYSQL_PASSWORD);
    	$bd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}catch(PDOException $e){
    	echo "probleme de connection de base de données : " . $e->getMessage();	}

$router = new Router();
$router->main(new ProduitsStorage($bd), new LogementsStorage($bd));
