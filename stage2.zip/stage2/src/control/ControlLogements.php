<?php

require_once("model/Logements.php");
require_once("view/View.php");

class ControlLogements{
  protected $view;
  protected $logementsStorage;

  public function __construct(View $view, LogementsStorage $logementsStorage){
    $this->view = $view;
    $this->logementsStorage = $logementsStorage;
  }

  public function showListLogement(){
    $this->view->LogementList($this->logementsStorage->readAll());
  }

  public function readContent($id){
    $this->view->HomePageContent($this->produitsStorage->read($id));
  }

}
