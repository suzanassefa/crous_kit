<?php

require_once("model/ProduitsStorage.php");
require_once("view/View.php");

class ControlProduits{
  protected $view;
  protected $produitsStorage;

  public function __construct(View $view, ProduitsStorage $produitsStorage){
    $this->view = $view;
    $this->produitsStorage = $produitsStorage;
  }

  public function showListProduit(){
    $this->view->HomePageList($this->produitsStorage->readAll());
  }

  public function readContent($id){
    $this->view->HomePageContent($this->produitsStorage->read($id));
  }

}
