<?php
require_once("Router.php");

class View{
  protected $router;
  protected $title;
  protected $content1;
  protected $content2;
  protected $menu;

  public function __construct(Router $router){
    $this->router = $router;
    $this->title = "";
    $this->content1 = "";
    $this->content2 = "";
    $this->menu = $this->getMenu();
  }

  public function render(){
    include_once("index.php");
  }

  public function getMenu(){
    return "<a href='".$this->router->getAccueilURL()."'>Accueil</a>
    <a href='".$this->router->getLogementsURL()."'>Logements</a>
    <a href='".$this->router->getBlanchisseriesURL()."'>Blanchisseries</a>
    <a href='".$this->router->getDeconnectionURL()."'>Deconnection</a>";
  }

  public function HomePageList($tableau){
    $this->content1 = "<ul id='menu-accordeon'>
	     <li><a href='#'>Produits</a>
		   <ul>";
    foreach ($tableau as $ligne){
      $this->content1 .= "<li><a href='".$this->router->getAccueilURL()."/produits/".$ligne['idNom']."'>".$ligne['categorie']."</a></li>";
    }
    $this->content1 .= "</ul>
      </li>
      <li><a href=''#''>Kits</a>
		  <ul>";
    foreach ($tableau as $ligne){
      $this->content1 .= "<li><a href='".$this->router->getAccueilURL()."/kits/".$ligne['idNom']."'>".$ligne['categorie']."</a></li>";
    }
    $this->content1 .= "</ul>
      </li>
      </ul>";
      $this->title = "Nom : ".$ligne['categorie']."</br>";
      $this->content2 .= "Inventaire : ".$ligne['inventaire']."</br>";
      $this->content2 .= "Date d'Inventaire : ".$ligne['dateInventaire']."</br>";
      $this->content2 .= "Quantié prêt : ".$ligne['pret']."</br>";
  }

  public function HomePageContent($ligne){
    $this->title = "Nom : ".$ligne['categorie'];
    $this->content2 .= "Inventaire : ".$ligne['inventaire'];
    $this->content2 .= "Date d'Inventaire : ".$ligne['dateInventaire'];
    $this->content2 .= "Quantié prêt : ".$ligne['pret'];

  }

  public function LogementList($tableau){
    include_once("LogementContent.php");
    $this->content2 .= "<a href='".$this->router->getKitFormulaireURL()."'> Ajouter un Kit</a> ";
  }

  public function kitFormualire(){
    include_once("kitFormulaire.php");
  }
}
