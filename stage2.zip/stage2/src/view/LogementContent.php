<?php
$this->content1 .="<form methode='POST' action='".$this->router->getAccueilURL()."/'>
  <label for='batiement'>Batiement</label>
  <select id='batiment' name='batiment'>
    <option value='A'>A</option>
    <option value='B'>B</option>
    <option value='C'>C</option>
  </select>
  <label for='etage'>Etage</label>
  <select id='etage' name='etage'>
    <option value='RDC'>RDC</option>
    <option value='1'>1</option>
    <option value='2'>2</option>
    <option value='3'>3</option>
    <option value='4'>4</option>
  </select>
</form>";
$this->content2 .=
  "  <table>
      <tr>
        <th>Nom du kit</th>
        <th>Date de pet</th>
        <th>Mantant facturé</th>
        <th>Payeur</th>
        <th>Payement effectué</th>
      </tr>
      <tr>
        <td>Alfreds Futterkiste</td>
        <td>Maria Anders</td>
        <td>Germany</td>
      </tr>
    </table>
    ";
