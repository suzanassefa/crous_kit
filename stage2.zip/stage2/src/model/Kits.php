<?php

class Kits{
  protected $nom;
  //protected $lieuStokage;
  protected $quantite;
  protected $description;
  protected $tarifs;
  protected $lieuStokage;

  public function __construct($nom, $quantite, $description, $tarifs, $lieuStokage){
    $this->nom = $nom;
    $this->quantite = $quantite;
    $this->description = $description;
    $this->tarifs = $tarifs;
    $this->lieuStokage = $lieuStokage;
  }

  public function getNom(){
    return $this->nom;
  }

  public function getQuantite(){
    return $this->quantite;
  }

  public function getDescription(){
    return $this->description;
  }

  public function getTarifs(){
    return $this->tarifs;
  }
  public function getLieuStockage(){
    return $this->lieuStokage;
  }
}
