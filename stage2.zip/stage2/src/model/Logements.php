<?php

class Logements{
  protected $nom;
  protected $batiment;
  protected $numeros;
  protected $type;

  public function __construct($nom, $batiment, $numeros, $type){
    $this->nom = $nom;
    $this->batiment = $batiment;
    $this->numeros = $numeros;
    $this->type = $type;
  }

  public function getNom(){
    return $this->nom;
  }

  public function getBatiment(){
    return $this->batiment;
  }

  public function getNumeros(){
    return $this->numeros;
  }

  public function getType(){
    return $this->type;
  }
}
